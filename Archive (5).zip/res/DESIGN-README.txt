Design Changes and Explanation:


Changes:

1.An IView interface was added to begin the basis for the GUI. This interface has the methods
addViewListener(IViewListener listener), which adds a listener to a certain view so the users
interactions with the interface can be monitored and the correct outputs can be handled. The other
method is setVisible(boolean value) which changes a given view to be visible if true is inputted and
makes a view not visible if the value is false.

2. The classes that implement this interface are all the windows that a user can see throughout
interacting with the interface. These include, NyView which is the main menu, ManagePortfolio which
handles managing a portfolio, BuyView which handles buying stock functionality, SellView which
handles SellStock functionality, CompView which handles portfolio composition functionality, and
ValueView which handles get portfolio value functionality. All of these classes extend JFrame and
also implement ActionVisitor (alongside IView). This allows for buttons and labels to be placed on
the windows, and also for actions to be taken when these buttons are pressed.

3. The IViewListener interface handles the connection between the controller and the view. In the
multiple view classes, IViewListeners are added as a field, which allows for actions to be sent to
the controller (IVisibleController), which implements IViewController, and utilizes a multitude of
methods.

4. The IVisibleController interface was added due to the fact that the original stock controller and
its interface did not allow enough functionality to support the GUI implementation. This new
interface extended IController. The reason StockController could not be used here is that it
included a ton of writeMessage() calls, which is a text based method that was used in the text
interface. To allow that class to work and support the GUI functionality, many changes would have to
occur, which would in turn create a much more confusing functionality instead of just extending to a
new Visual interface that is implemented in a VisibleController that connects the VisibleView with
the model.

5. The model was not changed at all and its functionality remained the same, however the API portion
was moved to its own isolated class and a API interface was added to create support for the addition
of other APIs.



