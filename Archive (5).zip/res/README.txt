Stock Program - GUI Version

The functionality of the programs are as follows:

1. Save portfolios:
        a. Select a portfolio from the dropdown menu of portfolios that are currently able to be
        worked on. None will appear at first, but once a new portfolio is created or uploaded, they
        will populate this dropdown box. When one is selected and save is pressed, the portfolio
        will save to the portfolios folder in the res and can be uploaded at a later date.

2. Upload portfolios:
        a. Select a portfolio from the dropdown menu of portfolios in the portfolios folder and press
        upload to retrieve it and work on it (manage). Once a portfolio is saved, it will go here as
        well.

3. Create portfolios:
        a. Enter a name into the text field and press the create button to create a portfolio and
        add it to the list of possible portfolios to be managed. This will also allow that portfolio
        to be saved.

4. Manage portfolio:
        a. Press this button to enter a new menu that will allow you to manage any of the portfolios
        that are in the list of current possible portfolios.


    Options in Mange Portfolio Menu:

        1. Buy Stock:
                a. Enter a ticker symbol, share amount, date, and select a portfolio from the
                dropdown menu, then press buy stocks to add to the portfolio.
                        i. If no portfolios appear in the dropdown, create a portfolio or upload one
                        to work on.

        2. Sell Stock:
                a. Enter a ticker symbol, share amount, date, and select a portfolio from the
                dropdown menu, then press sell stocks to add to the portfolio.
                        i. If no portfolios appear in the dropdown, create a portfolio or upload one
                        to work on.

        3. Get Value:
                a. Select a portfolio from the dropdown menu and enter a date. Press get value to
                query the value of the portfolio on that date.
                        i. If no portfolios appear in the dropdown, create a portfolio or upload one
                        to work on.

        4. Get Composition
                a. Select a portfolio from the dropdown menu and enter a date. Press get composition
                 to query the composition of the portfolio on that date.
                        i. If no portfolios appear in the dropdown, create a portfolio or upload one
                        to work on.


** All errors are handled and appear showcasing when an error occurs**

Thanks!