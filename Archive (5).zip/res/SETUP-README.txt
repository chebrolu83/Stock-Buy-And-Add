To Set Up The Program:

1. First place the hw6.jar file in a folder with both the stockData folder and the portfolios
folder. **THIS IS ESSENTIAL TO THE FILE WORKING**

2. Open the terminal and cd (navigate) to the folder that has the jar file and the 2
 additional folders.

3. Either enter java -jar hw6.jar to run the GUI version or java -jar hw6.jar -text to run the
text-based version.

4. From here, the program can be navigated and used.



