/**
 * * Represents a main class that can handle both the text based main adn the graphical user
 * * interface based main.
 */
public class Main {

  /**
   * Runs the program and either starts the GUI or the text-based interface.
   *
   * @param args the arguments of the program
   * @throws Exception if an error occurs
   */
  public static void main(String[] args) throws Exception {
    if (args.length > 0 && args[0].equals("-text")) {
      runText();
    } else {
      runGUI();
    }
  }

  // runs the text-based interface
  private static void runText() throws Exception {
    TextMain.main(new String[0]);
  }

  // runs the GUI
  private static void runGUI() throws Exception {
    VisibleMain.main(new String[0]);
  }
}

