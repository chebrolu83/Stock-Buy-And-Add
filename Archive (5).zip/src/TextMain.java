import java.io.InputStreamReader;

import controller.IController;
import controller.StockController;

/**
 * The view of the program that interacts with the controller to show the user the output of
 * their commands.
 */
public class TextMain {

  /**
   * Runs the stock program.
   *
   * @param args Arguments that will be scanned.
   */
  public static void main(String[] args) throws Exception {
    Readable rd = new InputStreamReader(System.in);
    Appendable ap = System.out;
    IController controller = new StockController(rd, ap);
    controller.start();

  }
}
