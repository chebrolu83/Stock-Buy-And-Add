
import controller.IVisibleController;
import controller.VisibleController;
import view.IView;
import view.MyView;

/**
 * Represents a visible GUI main that allows a user to interact with a window user interface and
 * access portfolio functionality.
 */
public class VisibleMain {

  /**
   * Main method that sends information to the controller to interact with the model's
   * functionality.
   *
   * @param args arguments to take inputs from
   * @throws Exception if an error occurs when running
   */
  public static void main(String[] args) throws Exception {
    IView view = new MyView();
    IVisibleController controller = new VisibleController(view);
    controller.start();

  }
}
