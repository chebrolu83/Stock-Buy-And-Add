package controller;

/**
 * Represents a controller that interacts between the view and model of the stock program to allow
 * users to call different commands on stocks and portfolios.
 */
public interface IController {

  /**
   * Starts the program and begins to ask users for inputs and relay these commands to the other
   * parts of the program.
   *
   * @throws Exception if any errors occur on startup or in typing an input
   */
  void start() throws Exception;
}
