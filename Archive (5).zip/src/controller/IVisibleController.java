package controller;

import java.io.IOException;
import java.time.LocalDate;

import view.IViewListener;

/**
 * Represents a controller for a visual interface that can interact with the model and the visual
 * view that takes a users input and relays it to the controller.
 */
public interface IVisibleController extends IController, IViewListener {


  /**
   * Gets a list of the portfolios currently housed in the model.
   *
   * @return a string that describes the portfolios
   */
  String getPortfolios();

  /**
   * Buys stocks for the current working portfolio of the model on a given date with a given
   * number of shares.
   *
   * @param stock     the symbol of the stock
   * @param numShares the number of shares
   * @param date      the date purchased
   * @throws Exception if there is an error when attempting to purchase a stock
   */
  void buyStocks(String stock, double numShares, LocalDate date) throws Exception;

  /**
   * Verifies the validity of a stock (if it is a real stock).
   *
   * @param stock the ticker symbol to be tested
   * @return a boolean describing if the stock is valid or not
   */
  boolean verifyStock(String stock);

  /**
   * Verifies that a stock has data for a given date.
   *
   * @param stock the ticker symbol to be tested
   * @param date  the date to be tested on
   * @return a boolean describing if a stock has data on that day
   */
  boolean verifyDate(String stock, LocalDate date);

  /**
   * Sells stocks for the current working portfolio of the model on a given date with a given
   * number of shares.
   *
   * @param ticker      the ticker symbol of the stock
   * @param shareAmount the amount of shares
   * @param date        the date to sell on
   * @throws Exception if an error occurs when trying to sell stocks
   */
  void sellStocks(String ticker, double shareAmount, LocalDate date) throws Exception;

  /**
   * Updates the current working portfolio of the model.
   *
   * @param port the name of the portfolio to work on
   */
  void updatePort(String port);

  /**
   * Creates a portfolio.
   *
   * @param port the name of the new portfolio
   */
  void createPort(String port);

  /**
   * Gets the value of a portfolio on a given date.
   *
   * @param date the given date to examine
   * @return a double describing the value of the portfolio
   */
  double getPortVal(LocalDate date);

  /**
   * Uploads a portfolio file to the list of portfolios that can be worked on.
   *
   * @param port the name of portfolio to upload
   */
  void uploadPort(String port);

  /**
   * Saves the current working portfolio to a folder to be accessed in the future.
   *
   * @throws IOException if there is an error when saving the portfolio
   */
  void savePort() throws IOException;

  /**
   * Gets the current composition of a working portfolio on a given date.
   *
   * @param date the date to get the composition on
   * @return a string describing the composition
   */
  String getComp(LocalDate date);

}
