package controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Model;
import model.StockModel;


/**
 * Represents the controller for the StockProgram, that controls the input of the user
 * and returns outputs based on the command.
 */
public class StockController implements IController {
  private final Appendable appendable;
  private final StockModel model;
  private final Scanner sc;

  /**
   * Creates a StockController with a given readable and appendable. Constructs a model also to use
   * in the program.
   *
   * @param readable   the readable that takes inputs
   * @param appendable the appendable that spits out results
   */
  public StockController(Readable readable, Appendable appendable) {
    if ((readable == null) || (appendable == null)) {
      throw new IllegalArgumentException("Sheet, readable or appendable is null");
    }
    this.appendable = appendable;
    this.model = new Model();
    this.sc = new Scanner(readable);
  }

  /**
   * Represents a start method that will initiate the sequencing and allow the user to interact with
   * the model and view to run commands and output the results.
   *
   * @throws Exception if an exception is encountered in processing
   */
  public void start() throws Exception {
    boolean quit = false;

    //print the welcome message
    this.welcomeMessage();

    while (!quit) {
      printMenu(); //continue until the user quits
      writeMessage("Type instruction: "); //prompt for the instruction name
      String userInstruction = sc.next(); //take an instruction name
      switch (userInstruction) {
        case "1":
          this.stockHelp();
          break;
        case "2":
          this.portfolio();
          break;
        case "3":
          this.viewHelp();
          break;
        case "4":
          this.downloadHelp();
          break;
        case "5":
          this.removeHelp();
          break;
        case "menu": //print the menu of supported instructions
          printMenu();
          break;
        case "q": //quit
        case "quit": //quit
          quit = true;
          break;
        default: //error due to unrecognized instruction
          boolean d = false;
          writeMessage(System.lineSeparator() + "Undefined instruction: " + userInstruction
                  + System.lineSeparator());
          sc.nextLine();
          break;

      }
    }

    //after the user has quit, print farewell message
    this.farewellMessage();

  }


  private void stockHelp() throws Exception {
    this.updateStock();
    boolean quit = false;
    while (!quit) {
      if (model.currentStockName().equals("null")) {
        quit = true;
      } else {
        this.stockMenu();
        writeMessage("Type instruction: ");
        String userInstruction = sc.next();
        switch (userInstruction) {
          case "1":
            this.singleDateHelp();
            break;
          case "2":
            this.marginHelp();
            break;
          case "3":
            this.movingHelp();
            break;
          case "4":
            this.crossoverHelp();
            break;
          case "5":
            this.stockGraph();
            break;
          case "6":
            this.stockHelp();
            break;
          case "b":
            quit = true;
            break;
          case "r":
            break;
          default:
            writeMessage(System.lineSeparator() + "Undefined instruction: " + userInstruction
                    + System.lineSeparator());
            sc.nextLine();
            break;
        }
      }
    }
  }


  private void portfolio() throws Exception {
    boolean quit = false;
    while (!quit) {
      portMenu();
      writeMessage("Type instruction: "); //prompt for the instruction name
      String userInstruction = sc.next();
      switch (userInstruction) {
        case "1":
          writeMessage(System.lineSeparator() + "The current list of portfolios: " +
                  model.getPortfolios() + System.lineSeparator());
          break;
        case "2":
          createPortHelp();
          break;
        case "3":
          editPort();
          break;
        case "4":
          portRemoveHelp();
          break;
        case "5":
          portUploadHelp();
          break;
        case "b":
          quit = true;
          break;
        case "r":
          break;
        default: //error due to unrecognized instruction
          writeMessage("Undefined instruction: " + userInstruction + System.lineSeparator());
          sc.nextLine();
          break;
      }
    }
  }


  protected void editPort() throws Exception {
    updatePort();
    boolean quit = false;
    while (!quit) {
      if (!model.validCurrentPort()) { ///Check to work
        return;
      }
      editPortMenu();
      writeMessage("Type instruction: ");
      String userInstruction = sc.next();
      switch (userInstruction) {
        case "1":
          stockFindHelp();
          break;
        case "2":
          portDistHelp();
          break;
        case "3":
          this.addStockHelp();
          break;
        case "4":
          removeStockHelp();
          break;
        case "5":
          rebalanceHelp();
          break;
        case "6":
          portValHelp();
          break;
        case "7":
          portModelHelp();
          break;
        case "8":
          savePortHelp();
          break;
        case "b":
          quit = true;
          break;
        case "r":
          break;
        default: //error due to unrecognized instruction
          writeMessage("Undefined instruction: " + userInstruction + System.lineSeparator());
          sc.nextLine();
          break;
      }
    }
  }

  private void portMenu() {
    writeMessage(System.lineSeparator() + "Available actions are:" + System.lineSeparator());
    writeMessage("1. View Portfolio List" + System.lineSeparator());
    writeMessage("2. Create Portfolio" + System.lineSeparator());
    writeMessage("3. Manage Portfolio" + System.lineSeparator());
    writeMessage("4. Remove Portfolio" + System.lineSeparator());
    writeMessage("5: Upload Portfolio" + System.lineSeparator());
    writeMessage("b (return to the menu)" + System.lineSeparator());
    writeMessage("r (review actions)" + System.lineSeparator());

  }

  protected void editPortMenu() {
    writeMessage(System.lineSeparator() + "Available actions are:" + System.lineSeparator());
    writeMessage("1. View Current Stock Composition" + System.lineSeparator());
    writeMessage("2. View Current Stock Distribution" + System.lineSeparator());
    writeMessage("3. Buy Stock" + System.lineSeparator());
    writeMessage("4. Sell Stock" + System.lineSeparator());
    writeMessage("5. Rebalance Portfolio" + System.lineSeparator());
    writeMessage("6. Get Value" + System.lineSeparator());
    writeMessage("7. Performance Table" + System.lineSeparator());
    writeMessage("8. Save Portfolio" + System.lineSeparator());
    writeMessage("b (back to portfolio menu)" + System.lineSeparator());
    writeMessage("r (review actions)" + System.lineSeparator());
  }

  protected void writeMessage(String message) throws IllegalStateException {
    try {
      appendable.append(message);

    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }

  private void printMenu() throws IllegalStateException {
    writeMessage(System.lineSeparator() + "Supported user instructions are: "
            + System.lineSeparator());
    writeMessage("1. View Stock Data" + System.lineSeparator());
    writeMessage("2. Portfolios" + System.lineSeparator());
    writeMessage("3. View List of Downloaded Stocks" + System.lineSeparator());
    writeMessage("4. Download Stock" + System.lineSeparator());
    writeMessage("5. Remove Stock" + System.lineSeparator());
    writeMessage("menu (Print supported instruction list)" + System.lineSeparator());
    writeMessage("q or quit (quit the program) " + System.lineSeparator());
  }

  private void stockMenu() throws IllegalStateException {
    writeMessage(System.lineSeparator() + "Available Actions:" + System.lineSeparator());
    writeMessage("1. Retrieve the closing value of a stock at a given date"
            + System.lineSeparator());
    writeMessage("2. Retrieve profit/loss of a stock over a period of time"
            + System.lineSeparator());
    writeMessage("3. Retrieve the moving-average for a given period of days prior to a user given "
            + "date" + System.lineSeparator());
    writeMessage("4. Retrieve a list of days in a given range where the closing value of a stock " +
            "is greater than the moving average over a given period" + System.lineSeparator());
    writeMessage("5. View performance over time" + System.lineSeparator());
    writeMessage("6. View the data of a new stock" + System.lineSeparator());
    writeMessage("b (return to the menu) " + System.lineSeparator());
    writeMessage("r (review actions)" + System.lineSeparator());
  }

  private void welcomeMessage() throws IllegalStateException {
    writeMessage(System.lineSeparator() + "Welcome to the stock program!"
            + System.lineSeparator());
  }

  private void farewellMessage() throws IllegalStateException {
    writeMessage(System.lineSeparator() + "Thank you for using this program!");
  }

  private void singleDateHelp() {
    boolean done = false;
    writeMessage(System.lineSeparator() + "What date would you like to get the value on: ");
    while (!done) {
      LocalDate date = returnDate();
      if (date != null) {
        try {
          writeMessage("The value of " + model.currentStockName() + " on " + date +
                  " was: " + model.getVal(date) + System.lineSeparator());
          done = true;
        } catch (Exception e) {
          if (e.getMessage().startsWith("Text")) {
            writeMessage("Error: A date was invalid" + System.lineSeparator());
          } else {
            writeMessage("Error: " + e.getMessage() + System.lineSeparator());
          }
        }
      } else {
        done = true;
      }
    }
  }

  private void marginHelp() throws Exception {
    boolean done = false;
    while (!done) {
      writeMessage(System.lineSeparator() + "Starting Date: ");
      LocalDate startDate = returnDate();
      writeMessage(System.lineSeparator() + "Ending Date: ");
      LocalDate endDate = returnDate();
      if (startDate != null && endDate != null) {
        try {
          writeMessage("The profit or loss of " + model.currentStockName() + " between "
                  + startDate + " and "
                  + endDate + " is: " + model.performance(startDate, endDate) + " dollars."
                  + System.lineSeparator());
          done = true;
        } catch (Exception e) {
          if (e.getMessage().startsWith("Text")) {
            writeMessage("Error: A date was invalid" + System.lineSeparator());
          } else {
            writeMessage("Error: " + e.getMessage() + System.lineSeparator());
          }
        }
      }
    }
  }

  private void movingHelp() throws Exception {
    boolean done = false;
    while (!done) {
      writeMessage(System.lineSeparator() + "Starting Date: ");
      LocalDate startDate = returnDate();
      if (startDate != null) {
        writeMessage("Enter an integer amount of days to retrieve the average over: ");
        try {
          int x = sc.nextInt();
          try {
            writeMessage("The " + x + "-day moving average of " + model.currentStockName()
                    + " from " +
                    startDate + " is: " + model.movingAvg(x, startDate) + " dollars."
                    + System.lineSeparator());
            done = true;
          } catch (Exception e) {
            writeMessage("Error: " + e.getMessage() + System.lineSeparator());
          }
        } catch (Exception e) {
          writeMessage("Error: Given x value is not an integer" + System.lineSeparator());
          sc.nextLine();
        }
      } else {
        done = true;
      }
    }
  }

  private void crossoverHelp() throws Exception {
    boolean done = false;

    while (!done) {
      writeMessage(System.lineSeparator() + "Starting Date: ");
      LocalDate startDate = returnDate();
      writeMessage(System.lineSeparator() + "Ending Date: ");
      LocalDate endDate = returnDate();
      if (startDate != null && endDate != null) {
        writeMessage("Enter an integer amount of days to retrieve the average over: ");
        int x;
        try {
          x = sc.nextInt();
          try {
            writeMessage("Days that present buy opportunities for " + model.currentStockName()
                    + " between " + startDate + " and " + endDate +
                    " are: " + model.xCrossOver(startDate, endDate, x)
                    + System.lineSeparator());
            done = true;
          } catch (Exception e) {
            writeMessage("Error: " + e.getMessage() + System.lineSeparator());
          }
        } catch (Exception e) {
          writeMessage("Error: Given x value is not an integer" + System.lineSeparator());
          sc.nextLine();
        }
      } else {
        done = true;
      }
    }
  }


  private void viewHelp() {
    File f = new File("res/stockData");
    File[] paths = f.listFiles();
    List<String> downloaded = new ArrayList<>();
    if (paths != null) {
      for (File file : paths) {
        String curr = file.getName();
        if (!curr.equals(".DS_Store")) {
          downloaded.add(curr.substring(0, curr.indexOf(".")));
        }
      }
    }
    writeMessage(System.lineSeparator() + "The downloaded stocks are " + downloaded +
            System.lineSeparator());
    boolean done = false;
    writeMessage("Type b to go back: ");
    while (!done) {
      String next = sc.next();
      if (next.equals("b")) {
        done = true;
      } else {
        writeMessage(System.lineSeparator() + "Input invalid (b to go back): ");
      }
    }
  }

  private void updateStock() throws Exception {
    boolean done = false;
    writeMessage(System.lineSeparator() + "Enter a stock-symbol to work with (b to go back): ");
    while (!done) {
      String next = sc.next();
      if (!next.equals("b")) {
        model.updateCurrentStock(next);
        try {
          model.addStockData();
          done = true;
        } catch (Exception e) {
          writeMessage("Error: " + e.getMessage() + System.lineSeparator()
                  + System.lineSeparator() + "Enter a valid stock-symbol (b to go back): ");
        }
      } else {
        done = true;
        model.updateCurrentStock("null");
      }
    }
  }


  protected void updatePort() {
    boolean done = false;
    writeMessage(System.lineSeparator()
            + "What is the name of the portfolio you want to edit (b to go back): ");
    while (!done) {
      String next = sc.next();
      if (!next.equals("b")) {
        try {
          model.updateCurrentPort(next);
          done = true;
        } catch (Exception e) {
          writeMessage("Error: " + e.getMessage() + System.lineSeparator()
                  + System.lineSeparator() + "Enter a valid portfolio name (b to go back): ");
        }
      } else {
        done = true;
      }
    }
  }


  private void downloadHelp() throws Exception {
    boolean done = false;
    String next;
    writeMessage(System.lineSeparator() + "Enter a stock-symbol to download (b to go back): ");
    while (!done) {
      next = sc.next();
      if (!next.equals("b")) {
        model.updateCurrentStock(next);
        File f = new File("/Users/Brendan/Documents/cs3500/hw4/stockData/"
                + model.currentStockName() + ".csv");
        if (!f.exists()) {
          try {
            model.download();
            writeMessage(model.currentStockName() + " has been downloaded and can be " +
                    "accessed next time the " + "program is run" + System.lineSeparator());
            done = true;
          } catch (Exception e) {
            writeMessage(System.lineSeparator() + "Error: " + e.getMessage() +
                    System.lineSeparator() +
                    "Enter a different stock to download (b to go back): ");
          }
        } else {
          writeMessage(System.lineSeparator() +
                  "Stock has already been downloaded!" + System.lineSeparator()
                  + "Enter a different stock to download (b to go back): ");
        }
      } else {
        done = true;
      }
    }
  }

  private void removeHelp() {
    writeMessage(System.lineSeparator() + "Enter stock-symbol to remove (b to go back): ");
    String next = sc.next();
    if (!next.equals("b")) {
      File f = new File("/Users/Brendan/Documents/cs3500/hw4/stockData/"
              + next + ".csv");
      boolean deleted = f.delete();
      if (deleted) {
        writeMessage(next + " will be removed from the list of downloaded stocks once " +
                "the program has been quit" + System.lineSeparator());
      } else {
        writeMessage(next + " not found");
      }
    }
  }


  protected void addStockHelp() throws Exception {
    boolean done = false;
    while (!done) {
      writeMessage(System.lineSeparator() +
              "What is the stock-symbol of the stock you want to buy (b to go back): ");
      String stockSymbol = sc.next();
      if (!stockSymbol.equals("b")) {
        writeMessage("How many shares would you like to buy: ");
        double shareCount = sc.nextDouble();
        writeMessage("What is the date you would like to buy on: ");
        try {
          LocalDate date = returnDate();
          model.updateCurrentStock(stockSymbol);
          model.addStockData();
          model.getVal(date);
          if (date == null) {
            return;
          }
          try {
            model.portAddStocks(stockSymbol, shareCount, date);
            writeMessage(shareCount + " share(s) of " + stockSymbol + " were added to the " +
                    model.getCurrentPortfolioName() + " portfolio" + System.lineSeparator());
          } catch (Exception e) {
            writeMessage("Error: " + e.getMessage() + System.lineSeparator());
          }
        } catch (Exception e) {
          writeMessage("Error: " + e.getMessage() + System.lineSeparator());
        }
      } else {
        done = true;
      }
    }
  }

  protected void removeStockHelp() throws Exception {
    boolean done = false;
    while (!done) {
      writeMessage(System.lineSeparator() +
              "What is the stock-symbol of the stock you want to sell (b to go back): ");
      String stockSymbol = sc.next();
      if (!stockSymbol.equals("b")) {
        writeMessage("How many shares would you like to sell: ");
        double shareCount = sc.nextDouble();
        writeMessage("On what date would you like to sell on: ");
        LocalDate date = returnDate();
        if (date == null) {
          return;
        }
        try {
          model.updateCurrentStock(stockSymbol);
          model.addStockData();
          model.getVal(date);
          model.portRemoveStocks(stockSymbol, shareCount, date);
          writeMessage(shareCount + " share(s) of " + stockSymbol + " were removed from the " +
                  model.getCurrentPortfolioName() + " portfolio" + System.lineSeparator());
          done = true;
        } catch (Exception e) {
          writeMessage("Error: " + e.getMessage() + System.lineSeparator());
        }
      } else {
        done = true;
      }
    }
  }

  private void portValHelp() throws Exception {
    boolean done = false;
    writeMessage(System.lineSeparator() + "What date would you like to retrieve the value: ");
    while (!done) {
      LocalDate date = returnDate();
      if (date == null) {
        break;
      }
      try {
        writeMessage("The value of " + model.getCurrentPortfolioName() + " on " + date + " is: " +
                model.portValue(date) + System.lineSeparator());
        done = true;
      } catch (Exception e) {
        writeMessage("Error: " + e.getMessage() + System.lineSeparator() +
                "Enter a different date (b to go back): " + System.lineSeparator());

      }
    }
  }

  protected void stockFindHelp() {
    writeMessage(System.lineSeparator() + "Date: ");
    boolean done = false;
    while (!done) {
      LocalDate start = returnDate();
      if (start == null) {
        break;
      }
      try {
        writeMessage(System.lineSeparator() + model.findPortStocksWithShares(start)
                + System.lineSeparator());
        done = true;
      } catch (Exception e) {
        writeMessage("Error " + e.getMessage() + System.lineSeparator());
      }
    }
  }


  private void createPortHelp() {
    writeMessage(System.lineSeparator() + "Enter a name for the portfolio (b to go back): ");
    String userName = sc.next();
    if (!userName.equals("b")) {
      model.createPortfolio(userName);
      writeMessage("New portfolio " + userName + " was created and can now be edited"
              + System.lineSeparator());
    }
  }

  private void portRemoveHelp() {
    writeMessage(System.lineSeparator() +
            "What portfolio do you want to remove (b to go back): ");
    boolean done = false;
    while (!done) {
      String next = sc.next();
      if (!next.equals("b")) {
        try {
          model.removePortfolio(next);
          writeMessage(next + " was removed from the list of portfolios " + System.lineSeparator());
          done = true;
        } catch (Exception e) {
          writeMessage(next + " does not exist." + System.lineSeparator() + System.lineSeparator() +
                  "Enter a different portfolio to remove (b to go back): ");
        }
      } else {
        done = true;
      }
    }
  }

  private void rebalanceHelp() {
    writeMessage(System.lineSeparator() + "Enter a date to rebalance on: ");
    boolean done = false;
    while (!done) {
      LocalDate date = returnDate();
      if (date == null) {
        break;
      }
      writeMessage(System.lineSeparator() +
              "What weights would you like to rebalance to (must add to 100): "
              + System.lineSeparator());
      String[] stocks = model.findPortStocks().split(",");
      List<Double> weights = new ArrayList<>();
      boolean end = false;
      for (String stock : stocks) {
        writeMessage("Weight for " + stock + " (b to go back): ");
        String s = sc.next();
        if (s.equals("b")) {
          end = true;
          break;
        }
        double w = Double.parseDouble(s);
        weights.add(w);
      }
      double sumWeights = weights.stream().mapToDouble(f -> f).sum();
      if (sumWeights != 100.0) {
        if (end) {
          break;
        }
        writeMessage("Error: Weights do not add up to 100" + System.lineSeparator()
                + System.lineSeparator() + "Enter a date to rebalance at: ");

      } else {
        try {
          model.rebalance(date, weights);
          writeMessage("Rebalance complete. The portfolio composition is now --> "
                  + model.findPortStocksWithShares(date) + System.lineSeparator());
          done = true;
        } catch (Exception e) {
          writeMessage("Error " + e.getMessage() + System.lineSeparator());
        }
      }
    }
  }

  private void savePortHelp() throws IOException {
    model.savePortfolio();
    writeMessage(System.lineSeparator() + "Portfolio " + model.getCurrentPortfolioName() +
            " was saved." +
            System.lineSeparator());
  }

  private void portUploadHelp() {
    writeMessage(System.lineSeparator() + "What is the name of the portfolio you want to upload " +
            "(b to go back): ");
    boolean done = false;
    while (!done) {
      String portName = sc.next();
      if (!portName.equals("b")) {
        try {
          model.portUpload(portName);
          writeMessage(portName + " was successfully uploaded and can now be edited" +
                  System.lineSeparator());
          done = true;
        } catch (Exception e) {
          writeMessage("Error: " + e.getMessage() + System.lineSeparator()
                  + System.lineSeparator() +
                  "Enter a different portfolio name (b to go back): ");
        }
      } else {
        done = true;
      }
    }
  }

  private void portModelHelp() {
    writeMessage(System.lineSeparator() + "Start Date: ");
    boolean done = false;
    while (!done) {
      LocalDate start = returnDate();
      if (start == null) {
        break;
      }
      writeMessage(System.lineSeparator() + "End Date: ");
      LocalDate end = returnDate();
      if (end == null) {
        break;
      }
      try {
        writeMessage(model.graphPort(start, end));
        done = true;
      } catch (Exception e) {
        writeMessage("Error " + e.getMessage() + System.lineSeparator());
      }
    }
  }

  private void stockGraph() {
    writeMessage(System.lineSeparator() + "Start Date: ");
    boolean done = false;
    while (!done) {
      LocalDate start = returnDate();
      if (start == null) {
        break;
      }
      writeMessage(System.lineSeparator() + "End Date: ");
      LocalDate end = returnDate();
      if (end == null) {
        break;
      }
      try {
        writeMessage(model.graphStock(start, end));
        done = true;
      } catch (Exception e) {
        writeMessage("Error: " + e.getMessage() + System.lineSeparator());
      }
    }
  }


  private String formatDate(String year, String month, String day) {
    String formatMonth = String.format("%02d", Integer.parseInt(month));
    String formatDay = String.format("%02d", Integer.parseInt(day));

    return year + "-" + formatMonth + "-" + formatDay;
  }

  private LocalDate returnDate() {
    boolean done = false;
    LocalDate toReturn = null;
    while (!done) {
      writeMessage(System.lineSeparator() + "Give a Year (b to go back): ");
      String year = sc.next();
      if (year.equals("b")) {
        break;
      }

      writeMessage("Give a Month (b to go back): ");
      String month = sc.next();
      if (month.equals("b")) {
        break;
      }

      writeMessage("Give a Day (b to go back): ");
      String day = sc.next();
      if (day.equals("b")) {
        break;
      }

      try {
        toReturn = LocalDate.parse(formatDate(year, month, day));
        done = true;
      } catch (Exception e) {
        writeMessage("Error: Date entered was invalid" + System.lineSeparator());
      }

    }
    return toReturn;
  }

  private void portDistHelp() {
    writeMessage(System.lineSeparator() + "Date: ");
    boolean done = false;
    while (!done) {
      LocalDate start = returnDate();
      if (start == null) {
        break;
      }
      try {
        writeMessage(System.lineSeparator() + model.findPortStocksWithVals(start)
                + System.lineSeparator());
        done = true;
      } catch (Exception e) {
        writeMessage("Error " + e.getMessage() + System.lineSeparator());
      }
    }
  }

}
