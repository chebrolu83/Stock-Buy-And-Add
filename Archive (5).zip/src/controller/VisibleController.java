package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Objects;

import model.Model;
import model.StockModel;
import view.IView;

/**
 * Represents a visible controller that handles a graphical user interface which takes inputs
 * from the user and connects those inputs to the model.
 */
public class VisibleController implements IVisibleController {
  private final StockModel model;
  private final IView view;

  /**
   * Constructs a visible controller.
   *
   * @param view the view of the MVC pattern
   */
  public VisibleController(IView view) {
    this.model = new Model();
    this.view = Objects.requireNonNull(view);
    this.view.addViewListener(this);
  }

  /**
   * Starts the program and begins to ask users for inputs and relay these commands to the other
   * parts of the program.
   *
   * @throws Exception if any errors occur on startup or in typing an input
   */
  @Override
  public void start() throws Exception {
    view.setVisible(true);
  }

  /**
   * Gets a list of the portfolios currently housed in the model.
   *
   * @return a string that describes the portfolios
   */
  @Override
  public String getPortfolios() {
    return model.getPortfolios();
  }

  /**
   * Buys stocks for the current working portfolio of the model on a given date with a given
   * number of shares.
   *
   * @param stock     the symbol of the stock
   * @param numShares the number of shares
   * @param date      the date purchased
   * @throws Exception if there is an error when attempting to purchase a stock
   */
  public void buyStocks(String stock, double numShares, LocalDate date) throws Exception {
    model.portAddStocks(stock, numShares, date);
  }

  /**
   * Verifies the validity of a stock (if it is a real stock).
   *
   * @param stock the ticker symbol to be tested
   * @return a boolean describing if the stock is valid or not
   */
  public boolean verifyStock(String stock) {
    model.updateCurrentStock(stock);
    try {
      model.addStockData();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  /**
   * Verifies that a stock has data for a given date.
   *
   * @param stock the ticker symbol to be tested
   * @param date  the date to be tested on
   * @return a boolean describing if a stock has data on that day
   */
  @Override
  public boolean verifyDate(String stock, LocalDate date) {
    try {
      model.updateCurrentStock(stock);
      model.addStockData();
      model.getVal(date);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  /**
   * Sells stocks for the current working portfolio of the model on a given date with a given
   * number of shares.
   *
   * @param ticker      the ticker symbol of the stock
   * @param shareAmount the amount of shares
   * @param date        the date to sell on
   * @throws Exception if an error occurs when trying to sell stocks
   */
  @Override
  public void sellStocks(String ticker, double shareAmount, LocalDate date) throws Exception {
    model.portRemoveStocks(ticker, shareAmount, date);
  }

  /**
   * Updates the current working portfolio of the model.
   *
   * @param port the name of the portfolio to work on
   */
  @Override
  public void updatePort(String port) {
    if (port.contains("Portfolio:")) {
      throw new IllegalArgumentException("Select a valid portfolio");
    }
    model.updateCurrentPort(port);
  }

  /**
   * Creates a portfolio.
   *
   * @param port the name of the new portfolio
   */
  @Override
  public void createPort(String port) {
    if (port.isBlank() || port.contains("Enter Name Here:")) {
      throw new IllegalArgumentException("Enter Valid Name");
    }
    model.createPortfolio(port);
  }

  /**
   * Gets the value of a portfolio on a given date.
   *
   * @param date the given date to examine
   * @return a double describing the value of the portfolio
   */
  @Override
  public double getPortVal(LocalDate date) {
    return model.portValue(date);
  }

  /**
   * Uploads a portfolio file to the list of portfolios that can be worked on.
   *
   * @param port the name of portfolio to upload
   */
  @Override
  public void uploadPort(String port) {
    if (port.contains("Portfolio:")) {
      throw new IllegalArgumentException("Select a valid portfolio");
    }
    try {
      model.portUpload(port);
    } catch (Exception e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  /**
   * Saves the current working portfolio to a folder to be accessed in the future.
   *
   * @throws IOException if there is an error when saving the portfolio
   */
  @Override
  public void savePort() throws IOException {
    model.savePortfolio();
  }

  /**
   * Gets the current composition of a working portfolio on a given date.
   *
   * @param date the date to get the composition on
   * @return a string describing the composition
   */
  @Override
  public String getComp(LocalDate date) {
    return model.findPortStocksWithShares(date);
  }

}
