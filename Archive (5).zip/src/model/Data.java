package model;

/**
 * Represents a stocks data on a given date.
 */
public class Data {
  private final double open;
  private final double high;
  private final double low;
  private final double close;
  private final long volume;

  /**
   * Allows the construction of a data object for one singular date.
   *
   * @param open   the opening value of a share
   * @param high   the high value of a share
   * @param low    the low value of a share
   * @param close  the closing value of a share
   * @param volume the volume of shares
   */
  public Data(double open, double high, double low, double close, long volume) {
    this.open = open;
    this.high = high;
    this.low = low;
    this.close = close;
    this.volume = volume;

  }

  // gets the value at close
  protected double getVal() {
    return this.close;
  }

  // gets the open
  protected double getOpen() {
    return this.open;
  }

  // gets the high
  protected double getHigh() {
    return this.high;
  }

  // gets the low
  protected double getLow() {
    return this.low;
  }

  // gets the volume
  protected long getVolume() {
    return this.volume;
  }
}

