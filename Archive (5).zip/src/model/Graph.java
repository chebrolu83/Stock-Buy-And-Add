package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import static java.util.concurrent.TimeUnit.DAYS;

/**
 * Represents a graph class that is an object which holds data that is relevant to graphing the
 * performance of a stock or a portfolio over a given range of dates.
 */
public class Graph {
  Portfolio port;
  LocalDate startDate;
  LocalDate endDate;
  Stock stock;
  boolean isPort;


  //Constructs the graph data for a portfolio.
  protected Graph(Portfolio port, LocalDate startDate, LocalDate endDate) {
    this.port = port;
    this.startDate = startDate;
    this.endDate = endDate;
    isPort = true;
  }

  //Constructs the graph data for a stock.
  protected Graph(Stock stock, LocalDate startDate, LocalDate endDate) {
    this.stock = stock;
    this.startDate = startDate;
    this.endDate = endDate;
    isPort = false;
  }


  // Graphs a stock or portfolio
  protected StringBuilder graph() {
    StringBuilder toReturn = new StringBuilder();


    double period = DAYS.toChronoUnit().between(startDate, endDate) + 1.0;

    if ((period / 365) >= 5 && (period / 365) <= 30) {
      double numRows = Math.floor(period / 365);
      toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.YEARS, 1));
    } else if ((period / 30) >= 5 && (period / 30) <= 30) {
      double numRows = Math.floor(period / 30);
      toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.MONTHS, 1));
    } else if ((period >= 5) && (period <= 30)) {
      toReturn.append(appendDate(startDate, endDate, period, ChronoUnit.DAYS, 1));
    }
    // more than 30 days less than 5 months
    else if ((period > 30) && (period / 30) < 5) {
      // less than 70 days
      if (period < 70) {
        double numRows = Math.floor(period / 3);
        toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.DAYS, 3));
      } else {
        // more than 70 days less than 5 months
        double numRows = Math.floor(period / 14);
        toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.DAYS, 14));
      }
    }
    // more than 30 months less than 5 years
    else if ((period / 30) > 30 && (period / 365) < 5) {
      double numRows = Math.floor(period / 90);
      toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.MONTHS, 3));
    } else if ((period / 365) > 5) {
      double numRows = Math.floor(period / 1095);
      toReturn.append(appendDate(startDate, endDate, numRows + 1, ChronoUnit.YEARS, 3));
    } else if (period < 5) {
      throw new IllegalArgumentException("Period must be greater than 5 days");
    }

    return toReturn;
  }

  // Appends the data for each period of time passing on the graph
  private StringBuilder appendDate(LocalDate start, LocalDate end,
                                   double numRows, ChronoUnit unit, int step) {
    double maxVal = 0.0;
    for (LocalDate curr = start; curr.isBefore(end); curr = curr.plus(1, unit)) {
      try {
        if (isPort) {
          if (this.port.getValue(curr) > maxVal) {
            maxVal = this.port.getValue(curr);
          }
        } else {
          if (this.stock.getDateValHelp(curr) > maxVal) {
            maxVal = this.stock.getDateValHelp(curr);
          }
        }
      } catch (Exception ignored) {
      }
    }
    double scale = Math.ceil(maxVal / 50);
    double roundScale = roundToNearestScale(scale);

    StringBuilder toReturn = new StringBuilder();
    LocalDate curr = start;
    for (int i = 1; i < numRows; i++) {
      double val = 0;
      boolean valid = false;
      LocalDate newDate = curr;
      while (!valid) {
        try {
          if (isPort) {
            val = port.getValue(newDate);
          } else {
            val = stock.getDateValHelp(newDate);
          }
          valid = true;
        } catch (Exception e) {
          newDate = newDate.minusDays(1);
        }
      }
      int count = Math.toIntExact(Math.round(val / roundScale));

      String month = newDate.getMonth().toString().charAt(0)
              + curr.getMonth().toString().substring(1, 3).toLowerCase();

      if (!newDate.isAfter(end)) {
        toReturn.append(curr.getYear()).append(" ").append(month).append(" ")
                .append(curr.getDayOfMonth())
                .append(": ").append("*".repeat(count)).append(System.lineSeparator());
      }
      curr = curr.plus(step, unit);
    }

    String endAbrv = end.getMonth().toString().charAt(0)
            + end.getMonth().toString().substring(1, 3).toLowerCase();
    double endVal = 0;
    boolean good = false;
    LocalDate newEnd = end;
    while (!good) {
      try {
        if (isPort) {
          endVal = port.getValue(newEnd);
        } else {
          endVal = stock.getDateValHelp(newEnd);
        }
        good = true;
      } catch (Exception e) {
        newEnd = newEnd.minusDays(1);
      }
    }
    int count = Math.toIntExact(Math.round(endVal / roundScale));
    toReturn.append(end.getYear()).append(" ").append(endAbrv).append(" ")
            .append(end.getDayOfMonth()).append(": ")
            .append("*".repeat(count)).append(System.lineSeparator());

    toReturn.append(System.lineSeparator()).append("Scale: * = ").append(roundScale)
            .append(" Dollars").append(System.lineSeparator());

    return toReturn;
  }

  private double roundToNearestScale(double number) {
    if (number == 0) {
      return 0;
    }

    String toString = String.valueOf(number);
    int length = toString.substring(0, toString.indexOf(".")).length();

    int val = 1;
    for (int i = 1; i < length; i++) {
      val *= 10;
    }
    double newVal = Math.round(number / val);
    return newVal * val;
  }
}
