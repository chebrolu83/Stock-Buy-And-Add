package model;

import java.io.IOException;

/**
 * Represents an interface for an API to retrieve stock data from.
 */
public interface IAPI {

  /**
   * Retrieves data from an API and returns it as a StringBuilder to be examined.
   *
   * @return a String builder of a stock's data
   * @throws IOException if there is an error retrieving the stock data
   */
  StringBuilder retrieveData() throws IOException;
}
