package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;


/**
 * Represents the model portion of the program that handles method calls from the controller
 * that happens as a result of user inputs.
 */
public class Model implements StockModel {
  private Stock currentStock;
  private final List<Portfolio> portfolios;
  private Portfolio currentPortfolio;

  /**
   * Constructs a new model.
   */
  public Model() {
    this.currentStock = null;
    this.portfolios = new ArrayList<Portfolio>();
    this.currentPortfolio = null;
  }


  //Retrieves the current stock of the model.
  private Stock getCurrentStock() {
    return this.currentStock;
  }

  /**
   * Retrieves the current stock's name in a string.
   *
   * @return a string of the current stocks name
   */
  public String currentStockName() {
    return getCurrentStock().getSymbol();
  }

  //Retrieves the current portfolio being worked on.
  private Portfolio getCurrentPortfolio() {
    return this.currentPortfolio;
  }


  /**
   * Returns true if the current portfolio is valid.
   *
   * @return a boolean describing the current portfolios validity
   */
  public boolean validCurrentPort() {
    return getCurrentPortfolio() != null;
  }

  /**
   * Retrieves the current portfolios name in string format.
   *
   * @return the name of the current working portfolio in the model
   */
  public String getCurrentPortfolioName() {
    return this.currentPortfolio.getName();
  }

  /**
   * Gets the composition of a portfolio on a given date.
   *
   * @param date the date to find the composition
   * @return a String describing which stocks are in a portfolio and how many shares there are on
   *            a given date
   */
  public String findPortStocksWithShares(LocalDate date) {
    return currentPortfolio.getStocksWithShares(date).toString();
  }

  /**
   * Gets the distribution of a portfolio on a given date.
   *
   * @param date the given date to find the distribution on
   * @return a String with the ticker symbols and the value of those stocks on the day
   */
  public String findPortStocksWithVals(LocalDate date) {
    return currentPortfolio.getStocksWithVals(date).toString();
  }

  /**
   * Gets a list of the current stocks in a portfolio in String form.
   *
   * @return a list of ticker symbols divided by commas
   */
  public String findPortStocks() {
    return currentPortfolio.getStocks().toString();
  }

  /**
   * Gets a list of the current portfolios in the model.
   *
   * @return a String that describes the current portfolios that are able to be accessed
   */
  public String getPortfolios() {
    StringJoiner sb = new StringJoiner(",");
    for (Portfolio portfolio : portfolios) {
      sb.add(portfolio.getName());
    }
    return sb.toString();
  }

  /**
   * Updates the currentStock of the model to be worked on.
   *
   * @param newName the ticker symbol of the new stock
   */
  public void updateCurrentStock(String newName) {
    this.currentStock = new Stock(newName);
  }

  /**
   * Updates the current portfolio of the model to be the name provided.
   *
   * @param newName the portfolio that will be worked on
   */
  public void updateCurrentPort(String newName) {
    this.currentPortfolio = findPortfolio(newName);
  }

  // Returns a portfolio with a given string in the list of the portfolios.
  private Portfolio findPortfolio(String name) {
    Portfolio toReturn = null;
    for (Portfolio portfolio : portfolios) {
      if (name.equals(portfolio.getName())) {
        toReturn = portfolio;
        break;
      }
    }
    if (toReturn == null) {
      throw new IllegalArgumentException("No portfolio with name " + name + " found");
    }
    return toReturn;
  }

  /**
   * Takes a start date and end date and determines the profit/loss of the current stock over that
   * time.
   *
   * @param start the start date
   * @param end   the second date
   * @return the value margin
   */
  @Override
  public double performance(LocalDate start, LocalDate end) {
    return currentStock.performanceHelp(start, end);
  }

  /**
   * Returns the average of a stock starting from a given date over the last x days.
   *
   * @param x     the amount of days to take the average from
   * @param start the starting date
   * @return the average of the current stock
   */
  @Override
  public double movingAvg(int x, LocalDate start) {
    return currentStock.movingAvgHelp(x, start);
  }

  /**
   * Finds the dates where the current stock's price crosses its x-period moving average.
   *
   * @param start the start date
   * @param end   the end date
   * @param x     the number of periods for the moving average
   * @return a list of dates where the stock price crosses the moving average
   */
  @Override
  public List<LocalDate> xCrossOver(LocalDate start, LocalDate end, int x) {
    return currentStock.xCrossOverHelp(start, end, x);
  }

  /**
   * Gets the value of the current stock on a specific date.
   *
   * @param date the date to get the value for
   * @return the value of the current stock on the specified date
   */
  @Override
  public double getVal(LocalDate date) {
    return currentStock.getDateValHelp(date);
  }

  /**
   * Creates a new portfolio with the specified name and adds it to the list of portfolios.
   *
   * @param name the name of the new portfolio
   */
  @Override
  public void createPortfolio(String name) {
    for (Portfolio portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        throw new IllegalArgumentException("Portfolio with name " + name + " already exists");
      }
    }
    portfolios.add(new Portfolio(name));
  }

  /**
   * Removes the portfolio with the specified name from the list of portfolios.
   *
   * @param portName the name of the portfolio to remove
   */
  @Override
  public void removePortfolio(String portName) {
    Portfolio toRemove = findPortfolio(portName);
    portfolios.remove(toRemove);
  }

  /**
   * Calculates the value of the current portfolio on a specific date.
   *
   * @param date the date to get the value for
   * @return the value of the current portfolio on the specified date
   * @throws IllegalArgumentException if no portfolio is currently selected
   */
  @Override
  public double portValue(LocalDate date) {
    return currentPortfolio.getValue(date);
  }

  /**
   * Adds stocks to the current portfolio.
   *
   * @param stock     the symbol of the stock to add
   * @param numShares the number of shares to add
   * @throws Exception if an error occurs while adding stocks
   */
  @Override
  public void portAddStocks(String stock, double numShares, LocalDate date) throws Exception {
    if (currentPortfolio != null) {
      Stock s = new Stock(stock);
      s.createStock(date);
      currentPortfolio.buyStock(s, numShares, date);
    }
  }

  /**
   * Removes stocks from the current portfolio.
   *
   * @param stockSymbol the symbol of the stock to remove
   * @param shareCount  the number of shares to remove
   * @param date        the date to sell the stocks
   * @throws Exception if an error occurs while removing stocks
   */
  @Override
  public void portRemoveStocks(String stockSymbol,
                               double shareCount, LocalDate date) throws Exception {
    Stock curr = new Stock(stockSymbol);
    curr.createStock(date);
    currentPortfolio.sellStock(curr, shareCount, date);
  }

  /**
   * Updates the current stock's information.
   *
   * @throws Exception if an error occurs while updating the stock
   */
  public void addStockData() throws Exception {
    currentStock.createStock(LocalDate.now());
  }

  /**
   * Downloads the current stock's data.
   *
   * @throws Exception if an error occurs while downloading the stock data
   */
  public void download() throws Exception {
    IAPI data = new StockVantageApi(currentStock.getSymbol());
    StringBuilder d = data.retrieveData();
    currentStock.downloadStock(d);
  }

  /**
   * Saves the current portfolios data to a csv file in the res.
   *
   * @throws IOException if the portfolio cannot be saved
   */
  public void savePortfolio() throws IOException {
    File f = new File("portfolios/" + getCurrentPortfolioName() + ".csv");
    FileWriter fw = new FileWriter(f);
    fw.write("Stock, Current Shares, Transaction History" + System.lineSeparator());
    fw.write(currentPortfolio.portSave());
    fw.close();

  }

  /**
   * Uploads a portfolio to a file to be accessed at a later date.
   *
   * @param name the name of the portfolio that needs to be uploaded
   * @throws IOException if there is an error when the portfolio is being uploaded (e.g. no
   *                     portfolio with that name in the files)
   */
  public void portUpload(String name) throws IOException {
    File f = new File("portfolios/" + name + ".csv");
    Portfolio toReturn = new Portfolio(name);
    boolean repeat = false;
    for (Portfolio portfolio : portfolios) {
      if (portfolio.getName().equals(toReturn.getName())) {
        repeat = true;
        break;
      }
    }
    if (!repeat) {
      if (!f.exists()) {
        throw new IllegalArgumentException("Portfolio " + getCurrentPortfolioName() +
                " does not exist");
      } else {
        BufferedReader br = new BufferedReader(new FileReader(f));
        String line;
        br.readLine();
        while ((line = br.readLine()) != null) {
          try {
            String[] parts = line.split(",");
            String stockSymbol = parts[0];
            double currShares = Double.parseDouble(parts[1]);
            Stock s = new Stock(stockSymbol);
            for (int i = 2; i < parts.length; i += 2) {
              LocalDate date = LocalDate.parse(parts[i]);
              double share = Double.parseDouble(parts[i + 1]);

              s.recordTransaction(date, share);
            }

            s.createStock(LocalDate.now());
            toReturn.addStock(s, currShares);

          } catch (Exception e) {
            throw new IllegalArgumentException("File cannot be read (incorrect format)");
          }
        }
        br.close();
        portfolios.add(toReturn);
      }
    } else {
      throw new IllegalArgumentException(toReturn.getName() + " has already been uploaded");
    }
  }

  /**
   * Rebalances a portfolios stocks to the given weights on the given date.
   *
   * @param date    the given date the balancing will take place on
   * @param weights the weights that the stocks will be rebalanced to
   */
  public void rebalance(LocalDate date, List<Double> weights) {
    double total = 0;
    for (double w : weights) {
      total += w;
    }
    if (total != 100) {
      throw new IllegalArgumentException("Weights do not add up to 100");
    } else {
      currentPortfolio.portRebalance(date, weights);
    }
  }

  /**
   * Graphs portfolio data between two dates in the form of a string with asterisks.
   *
   * @param startDate the start date of the range
   * @param endDate   the end date of the range
   * @return a String depicting the performance of a portfolio over time
   */
  public String graphPort(LocalDate startDate, LocalDate endDate) {
    return currentPortfolio.graph(startDate, endDate).toString();
  }

  /**
   * Graphs the performance of a stock over a given period of time.
   *
   * @param startDate the starting date of the range
   * @param endDate   the ending date of the range.
   * @return a string that depicts a graph of performance
   */
  public String graphStock(LocalDate startDate, LocalDate endDate) {
    return currentStock.graph(startDate, endDate).toString();
  }


}


