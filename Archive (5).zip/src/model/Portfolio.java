package model;

import java.time.LocalDate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;


/**
 * Represents a portfolio of purchased stocks with a certain number of shares each.
 */
public class Portfolio {
  private final String name;
  protected final Map<Stock, Double> stocks;

  // Constructors a new portfolio with an empty list of stocks.
  protected Portfolio(String name) {
    this.name = name;
    this.stocks = new HashMap<>();
  }


  // Returns the string version of a portfolio to be saved
  protected String portSave() {
    StringBuilder toReturn = new StringBuilder();
    for (Stock stock : stocks.keySet()) {
      StringJoiner sj = new StringJoiner(",");
      sj.add(stock.getSymbol());
      sj.add(Double.toString(stocks.get(stock)));
      sj.add(stock.transactionToString());
      toReturn.append(sj).append(System.lineSeparator());
    }
    return toReturn.toString();
  }

  // Gets the value of a portfolio on a given date
  protected double getValue(LocalDate date) {
    double toReturn = 0.0;
    for (Stock stock : stocks.keySet()) {
      toReturn += stock.getDateValHelp(date) * stock.getSharesOnDate(date);
    }
    return toReturn;
  }

  // Returns a StringJoiner of the stocks in a portfolio as well as how many
  // shares there are of each one
  protected StringJoiner getStocksWithShares(LocalDate date) {
    StringJoiner sb = new StringJoiner(", ");
    for (Stock s : stocks.keySet()) {
      if (s.getSharesOnDate(date) > 0) {
        sb.add(s.getSymbol() + ": " + s.getSharesOnDate(date));
      }
    }
    return sb;
  }

  // Returns a StringJoiner of the stocks in a portfolio as well as how much value each stock
  // currently has
  protected StringJoiner getStocksWithVals(LocalDate date) {
    StringJoiner sb = new StringJoiner(", ");
    for (Stock s : stocks.keySet()) {
      if (s.getDateValHelp(date) > 0) {
        sb.add(s.getSymbol() + ": " + s.getDateValHelp(date) * s.getSharesOnDate(date));
      }
    }
    return sb;
  }

  // Returns a StringJoiner of the stocks in a portfolio
  protected StringJoiner getStocks() {
    StringJoiner sb = new StringJoiner(",");
    for (Stock s : stocks.keySet()) {
      sb.add(s.getSymbol());
    }
    return sb;
  }

  // Returns the name of a portfolio
  protected String getName() {
    return this.name;
  }


  // Buys a specific number of shares of a specific stock on a specified date
  protected void buyStock(Stock stock, double numShares, LocalDate date) {
    if (numShares <= 0) {
      throw new IllegalArgumentException("Cannot buy non-positive number of shares");
    }
    boolean replaced = false;
    for (Stock s : stocks.keySet()) {
      if (s.getSymbol().equals(stock.getSymbol())) {
        replaced = true;
        s.recordTransaction(date, numShares);
        addStock(s, numShares);
      }
    }
    if (!replaced) {
      stock.recordTransaction(date, numShares);
      addStock(stock, numShares);
    }
  }

  // Sells a specific number of shares of a specific stock on a specified date
  protected void sellStock(Stock stock, double numShares, LocalDate date) {
    if (numShares <= 0) {
      throw new IllegalArgumentException("Cannot sell non-positive number of shares");
    }
    if (stocks.isEmpty()) {
      throw new IllegalArgumentException("This portfolio is currently empty");
    }
    for (Stock s : stocks.keySet()) {
      if (s.getSymbol().equals(stock.getSymbol())) {
        if (s.checkTrans(date)) {
          throw new IllegalArgumentException("Can't sell as there are no shares of this stock" +
                  " purchased before the given date");
        }
      }
    }
    boolean replaced = false;
    for (Stock s : stocks.keySet()) {
      if (s.getSymbol().equals(stock.getSymbol())) {
        replaced = true;
        s.recordTransaction(date, -numShares);
        try {
          removeStock(s, numShares);
        } catch (Exception e) {
          throw new IllegalArgumentException(e.getMessage());
        }
      }
    }
    if (!replaced) {
      throw new IllegalArgumentException("There are no shares of " + stock.getSymbol()
              + " in this " + "portfolio");
    }
  }

  // Adds a stock to a portfolio
  protected void addStock(Stock stock, double numShares) {
    stocks.merge(stock, numShares, Double::sum);
  }

  // Removes a stock from a portfolio
  private void removeStock(Stock s, double numShares) {
    if (numShares > stocks.get(s)) {
      throw new IllegalArgumentException("Attempting to sell more stocks than are present in the " +
              "portfolio");
    }
    stocks.replace(s, stocks.get(s) - numShares);
  }

  // Rebalances a portfolios stocks on a given date with given weights
  protected void portRebalance(LocalDate date, List<Double> weights) {
    double currVal = getValue(date);
    int index = 0;
    for (Stock s : stocks.keySet()) {
      double currShares = s.getSharesOnDate(date);
      double weight = weights.get(index) / 100;
      double newVal = currVal * weight;
      double newShares = newVal / s.getDateValHelp(date);
      double shares = currShares - newShares;
      if (shares < 0) {
        buyStock(s, Math.abs(shares), date);
      } else {
        sellStock(s, Math.abs(shares), date);
      }

      index++;
    }
  }

  // Graphs a portfolio's performance over time
  protected StringBuilder graph(LocalDate startDate, LocalDate endDate) {
    StringBuilder toReturn = new StringBuilder();

    toReturn.append(System.lineSeparator()).append("Performance of Portfolio ")
            .append(name).append(" from ").append(startDate).append(" to ")
            .append(endDate).append(":").append(System.lineSeparator())
            .append(new Graph(this, startDate, endDate).graph());

    return toReturn;
  }

}