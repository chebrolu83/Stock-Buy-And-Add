package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringReader;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;


/**
 * Represents a stock that houses its ticker symbol, a map of its data on each valid date, and a
 * list of the history of the transactions.
 */
public class Stock {
  private final String stockSymbol;
  private final Map<LocalDate, Data> data;
  private final List<Transaction> transactions;


  // Constructs a new stock with a given stockSymbol and its data currently empty.
  protected Stock(String stockSymbol) {
    this.data = new TreeMap<>();
    this.stockSymbol = stockSymbol;
    this.transactions = new ArrayList<>();
  }

  // Records a transaction
  protected void recordTransaction(LocalDate date, double shares) {
    transactions.add(new Transaction(date, shares));
  }

  // Returns the number of shares on a specific date
  protected double getSharesOnDate(LocalDate date) {
    return transactions.stream()
            .filter(t -> !t.getDate().isAfter(date))
            .mapToDouble(Transaction::getShares)
            .sum();
  }

  // Returns the transaction history as a string
  protected String transactionToString() {
    StringJoiner output = new StringJoiner(",");
    for (Transaction t : transactions) {
      output.add(t.transactionHelp());
    }
    return output.toString();
  }


  // Adds data to a stock
  protected void addData(LocalDate date, Data data) {
    this.data.put(date, data);
  }


  // Returns a value stating the gain/loss of a stock over a period of time
  protected double performanceHelp(LocalDate start, LocalDate end) {
    if (!data.containsKey(start) || !data.containsKey(end)) {
      throw new IllegalArgumentException("There is no data available for one or " +
              "both of the given dates");
    } else if (end.isBefore(start)) {
      throw new IllegalArgumentException("The end date cannot be before the start date");
    }
    return data.get(end).getVal() - data.get(start).getVal();
  }

  // Returns the average of a stock starting from a given date over the last x days
  protected double movingAvgHelp(int x, LocalDate start) {
    LocalDate current = start;
    double running = 0;
    int validDays = 0;
    if (!data.containsKey(start)) {
      throw new IllegalArgumentException("There is no data available for the given start date");
    }
    while (validDays < x) {
      if (data.containsKey(current)) {
        running += data.get(current).getVal();
        validDays++;
      }
      current = current.minusDays(1);
    }
    return running / x;
  }

  // Between range of dates, returns a list of days that the closing value for that day is greater
  // than the average over the last x days
  protected List<LocalDate> xCrossOverHelp(LocalDate start, LocalDate end, int x) {
    if (!data.containsKey(start) || !data.containsKey(end)) {
      throw new IllegalArgumentException("There is no data available for either the given " +
              "start date or end date ");
    }
    List<LocalDate> result = new ArrayList<>();
    boolean between = false;
    LocalDate current = start;
    int addDays = 1;
    boolean notValid = false;
    while (!between) {
      double currVal = data.get(current).getVal();
      if (currVal > this.movingAvgHelp(x, current)) {
        result.add(current);
      }
      while (!notValid) {
        LocalDate next = current.plusDays(addDays);
        if (!data.containsKey(next)) {
          addDays++;
        } else {
          notValid = true;
          current = next;
        }
      }
      notValid = false;
      addDays = 1;
      if (current.isAfter(end)) {
        between = true;
      }
    }
    return result;
  }

  // Returns the value for a stock on a given day
  protected double getDateValHelp(LocalDate date) {
    if (!data.containsKey(date)) {
      throw new IllegalArgumentException("There is no data available this date");
    }
    return data.get(date).getVal();
  }

  // Downloads a stock into the stockData folder if connected to the Wi-Fi
  protected void downloadStock(StringBuilder output) throws Exception {
    if (output.toString().contains("Thank you")) {
      throw new IllegalArgumentException("Queries have been used up, attempt to download tomorrow");
    }
    Path path = Path.of("stockData/" + stockSymbol + ".csv");
    File f = new File(path.toString()).getAbsoluteFile();
    FileWriter fw = new FileWriter(f);
    fw.write(output.toString());
    fw.close();
  }

  // Adds the data of a stock either from the stockData directory or the API
  protected void createStock(LocalDate date) throws Exception {
    BufferedReader br;
    Path path = Path.of("stockData/" + stockSymbol + ".csv");
    File f = new File(path.toString()).getAbsoluteFile();
    if (!f.exists()) {
      IAPI d = new StockVantageApi(stockSymbol);
      StringBuilder data = d.retrieveData();
      if (data.toString().contains("Invalid API call")) {
        throw new IllegalArgumentException("Stock does not exist or is not downloaded");
      } else {
        downloadStock(data);
        br = new BufferedReader(new StringReader(data.toString()));
      }
    } else {
      br = new BufferedReader(new FileReader(f));
    }
    String line;
    br.readLine();
    while ((line = br.readLine()) != null) {
      try {
        String[] parts = line.split(",");
        String dateString = parts[0];
        double open = Double.parseDouble(parts[1]);
        double high = Double.parseDouble(parts[2]);
        double low = Double.parseDouble(parts[3]);
        double close = Double.parseDouble(parts[4]);
        long volume = Long.parseLong(parts[5]);
        Data toAdd = new Data(open, high, low, close, volume);
        LocalDate dateToAdd = LocalDate.parse(dateString);

        this.addData(dateToAdd, toAdd);
      } catch (Exception e) {
        throw new IllegalArgumentException("File cannot be read (incorrect format)");
      }
    }
    br.close();
    if (!this.data.containsKey(date)) {
      File f2 = new File("stockData/" + stockSymbol + ".csv");
      f2.delete();
      createStock(date);
    }
  }


  // Gets the symbol of a stock
  protected String getSymbol() {
    return this.stockSymbol;
  }

  // Graphs the performance of a stock over time
  protected StringBuilder graph(LocalDate start, LocalDate end) {
    StringBuilder toReturn = new StringBuilder();

    toReturn.append(System.lineSeparator()).append("Performance of Stock ")
            .append(stockSymbol).append(" from ").append(start).append(" to ")
            .append(end).append(":").append(System.lineSeparator())
            .append(new Graph(this, start, end).graph());

    return toReturn;
  }

  protected boolean checkTrans(LocalDate date) {
    boolean invalid = true;
    for (Transaction t : transactions) {
      if (t.getDate().isBefore(date)) {
        invalid = false;
      }
      if (t.getDate().isEqual(date)) {
        invalid = false;
      }
      break;
    }
    return invalid;
  }


}

