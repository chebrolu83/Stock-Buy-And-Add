package model;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Represents the model interface that interacts with the stock controller to run commands on either
 * stocks or portfolios.
 */
public interface StockModel {

  /**
   * Takes a start date and end date and determines the profit/loss of the current stock over that
   * time.
   *
   * @param start the start date
   * @param end   the end date
   * @return the value margin between those two dates
   */
  double performance(LocalDate start, LocalDate end);

  /**
   * Returns the average of a stock starting from a given date over the last x days.
   *
   * @param x     the amount of days to take the average from
   * @param start the starting date
   * @return the average of the current stock
   */
  double movingAvg(int x, LocalDate start);

  /**
   * Finds the dates where the current stock's price crosses its x-period moving average.
   *
   * @param start the start date
   * @param end   the end date
   * @param x     the number of days for the moving average
   * @return a list of dates where the stock price crosses the moving average
   */
  List<LocalDate> xCrossOver(LocalDate start, LocalDate end, int x);

  /**
   * Gets the value of the current stock on a specific date.
   *
   * @param date the date to get the value for
   * @return the value of the current stock on the specified date
   */
  double getVal(LocalDate date);

  /**
   * Creates a new portfolio with the specified name and adds it to the list of portfolios.
   *
   * @param name the name of the new portfolio
   */
  void createPortfolio(String name);

  /**
   * Removes the portfolio with the specified name from the list of portfolios.
   *
   * @param portName the name of the portfolio to remove
   */
  void removePortfolio(String portName);

  /**
   * Calculates the value of the current portfolio on a specific date.
   *
   * @param date the date to get the value for
   * @return the value of the current portfolio on the specified date
   * @throws IllegalArgumentException if no portfolio is currently selected
   */
  double portValue(LocalDate date);

  /**
   * Adds stocks to the current portfolio.
   *
   * @param stock     the symbol of the stock to add
   * @param numShares the number of shares to add
   * @param date      the date to buy those stocks
   * @throws Exception if an error occurs while adding stocks
   */
  void portAddStocks(String stock, double numShares, LocalDate date) throws Exception;

  /**
   * Removes stocks from the current portfolio.
   *
   * @param stockSymbol the symbol of the stock to remove
   * @param shareCount  the number of shares to remove
   * @param date        the date to sell the stocks
   * @throws Exception if an error occurs while removing stocks
   */
  void portRemoveStocks(String stockSymbol, double shareCount, LocalDate date) throws Exception;

  /**
   * Updates the current stock's information.
   *
   * @throws Exception if an error occurs while updating the stock
   */
  void addStockData() throws Exception;

  /**
   * Downloads the current stock's data onto a csv file placed in the res.
   *
   * @throws Exception if an error occurs while downloading the stock data
   */
  void download() throws Exception;

  /**
   * Saves the current portfolios data to a csv file in the res.
   *
   * @throws IOException if the portfolio cannot be saved
   */
  void savePortfolio() throws IOException;

  /**
   * Uploads a portfolio to be accessed at a later date.
   * @param name the name of the portfolio that needs to be uploaded
   * @throws IOException if there is an error when the portfolio is being uploaded (e.g. no
   *                     portfolio with that name in the files)
   */
  void portUpload(String name) throws IOException;

  /**
   * Rebalances a portfolios stocks to the given weights on the given date.
   *
   * @param date    the given date the rebalancing will take place on
   * @param weights the weights that the stocks will be rebalanced to
   */
  void rebalance(LocalDate date, List<Double> weights);

  /**
   * Gets a list of the current portfolios in the model.
   *
   * @return a String that describes the current portfolios that are able to be accessed
   */
  String getPortfolios();

  /**
   * Gets the name of the current stock being worked on in the model.
   *
   * @return a String of the ticker symbol of the current stock
   */
  String currentStockName();

  /**
   * Updates the currentStock of the model to be worked on.
   *
   * @param newName the ticker symbol of the new stock
   */
  void updateCurrentStock(String newName);

  /**
   * Graphs portfolio data between two dates in the form of a string with asterisks.
   *
   * @param startDate the start date of the range
   * @param endDate   the end date of the range
   * @return a String depicting the performance of a portfolio over time
   */
  String graphPort(LocalDate startDate, LocalDate endDate);

  /**
   * Gets the composition of a portfolio on a given date.
   *
   * @param date the date to find the composition
   * @return a String describing which stocks are in a portfolio and how many shares there are on
   *              a given date
   */
  String findPortStocksWithShares(LocalDate date);

  /**
   * Gets a list of the current stocks in a portfolio in String form.
   *
   * @return a list of ticker symbols divided by commas
   */
  String findPortStocks();

  /**
   * Retrieves the name of the current portfolio of the model.
   *
   * @return a string of a portfolio name
   */
  String getCurrentPortfolioName();

  /**
   * Updates the current portfolio of the model to be the name provided.
   *
   * @param newName the portfolio that will be worked on
   */
  void updateCurrentPort(String newName);

  /**
   * Graphs the performance of a stock over a given period of time.
   *
   * @param startDate the starting date of the range
   * @param endDate   the ending date of the range.
   * @return a string that depicts a graph of performance
   */
  String graphStock(LocalDate startDate, LocalDate endDate);

  /**
   * Returns true if the current portfolio is valid.
   *
   * @return a boolean describing the current portfolios validity
   */
  boolean validCurrentPort();

  /**
   * Gets the distribution of a portfolio on a given date.
   *
   * @param date the given date to find the distribution on
   * @return a String with the ticker symbols and the value of those stocks on the day
   */
  String findPortStocksWithVals(LocalDate date);
}