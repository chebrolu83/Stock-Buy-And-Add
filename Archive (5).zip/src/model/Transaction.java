package model;

import java.time.LocalDate;

/**
 * Represents a transaction for a stock, including the date and the number of shares.
 */
public class Transaction {
  private final LocalDate date;
  private final double shares;


  //Constructs a new transaction with a given date and number of shares.
  protected Transaction(LocalDate date, double shares) {
    this.date = date;
    this.shares = shares;
  }

  // Gets the date of the transaction.
  protected LocalDate getDate() {
    return date;
  }

  // Gets the number of shares for the transaction.
  protected double getShares() {
    return shares;
  }

  // returns the date of a transaction and its amount of shares
  protected String transactionHelp() {
    return date.toString() + "," + shares;
  }

}
