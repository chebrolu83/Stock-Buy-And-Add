package view;



import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.time.LocalDate;
import java.util.Objects;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.Timer;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.BorderFactory;
import java.awt.Insets;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JFrame;


/**
 * Represents the view that provides that functionality for buying stocks on the GUI.
 */
public class BuyView extends JFrame implements IView, ActionListener {
  private final JTextField shareField;
  private final JTextField dateField;
  private final JTextField tickerField;
  private final JComboBox<String> portfolios;
  private final JButton back;
  private final JButton buy;
  private IView view;
  private IViewListener myListener;
  private final JLabel resultLabel;
  private final Timer time;


  private static final String PLACEHOLDER = "YYYY-MM-DD";
  private static final String TICKPLACE = "ex: GOOG";
  private static final String SHAREPLACE = "ex: 5";



  /**
   * Constructs the view for the buy stocks functionality.
   *
   * @param view the previous view window before buy
   */
  public BuyView(IView view) {
    super();
    setSize(new Dimension(900, 300));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    setLayout(new BorderLayout());
    JPanel mainPanel = new JPanel(new GridBagLayout());
    JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
    inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(10, 10, 10, 10);
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JPanel resultPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

    this.view = view;

    JLabel ticker = new JLabel("Enter Ticker Symbol:");
    JLabel shareAmount = new JLabel("Enter Share Amount:");
    JLabel dateLabel = new JLabel("Enter Date:");
    this.resultLabel = new JLabel();
    resultLabel.setForeground(Color.RED);
    resultPanel.add(resultLabel);

    this.tickerField = new JTextField(10);
    this.shareField = new JTextField(10);
    this.dateField = new JTextField(10);


    dateField.setText(PLACEHOLDER);
    dateField.setForeground(Color.GRAY);

    tickerField.setText(TICKPLACE);
    tickerField.setForeground(Color.GRAY);

    shareField.setText(SHAREPLACE);
    shareField.setForeground(Color.GRAY);

    dateField.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(FocusEvent e) {
        if (dateField.getText().equals(PLACEHOLDER)) {
          dateField.setText("");
          dateField.setForeground(Color.BLACK);
        }
      }

      @Override
      public void focusLost(FocusEvent e) {
        if (dateField.getText().isEmpty()) {
          dateField.setText(PLACEHOLDER);
          dateField.setForeground(Color.GRAY);
        }
      }
    });

    tickerField.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(FocusEvent e) {
        if (tickerField.getText().equals(TICKPLACE)) {
          tickerField.setText("");
          tickerField.setForeground(Color.BLACK);
        }
      }

      @Override
      public void focusLost(FocusEvent e) {
        if (tickerField.getText().isEmpty()) {
          tickerField.setText(TICKPLACE);
          tickerField.setForeground(Color.GRAY);
        }
      }
    });

    shareField.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(FocusEvent e) {
        if (shareField.getText().equals(SHAREPLACE)) {
          shareField.setText("");
          shareField.setForeground(Color.BLACK);
        }
      }

      @Override
      public void focusLost(FocusEvent e) {
        if (shareField.getText().isEmpty()) {
          shareField.setText(SHAREPLACE);
          shareField.setForeground(Color.GRAY);
        }
      }
    });


    // Add components to inputPanel
    inputPanel.add(ticker);
    inputPanel.add(tickerField);
    inputPanel.add(shareAmount);
    inputPanel.add(shareField);
    inputPanel.add(dateLabel);
    inputPanel.add(dateField);


    this.portfolios = new JComboBox<>();
    this.buy = new JButton("Buy Stock");
    this.back = new JButton("Back to Menu");

    buy.setActionCommand("buy");
    back.setActionCommand("back");


    buttonPanel.add(portfolios);
    buttonPanel.add(buy);
    buttonPanel.add(back);


    c.anchor = GridBagConstraints.CENTER;
    c.gridx = 0;
    c.gridy = 0;
    mainPanel.add(inputPanel, c);
    c.gridy = 1;
    mainPanel.add(buttonPanel, c);
    c.gridy = 2;
    mainPanel.add(resultPanel, c);



    JPanel dummyPanel = new JPanel();
    dummyPanel.setPreferredSize(new Dimension(0, 0));
    dummyPanel.setFocusable(true);
    mainPanel.add(dummyPanel);



    add(mainPanel, BorderLayout.CENTER);

    time = new Timer(4000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        resultLabel.setVisible(false);
        resultLabel.setForeground(Color.RED);
      }
    });
    time.setRepeats(false);



  }

  /**
   * Adds the view listener from before to this class to retrieve inputs.
   *
   * @param listener the listener that will retrieve inputs
   */
  @Override
  public void addViewListener(IViewListener listener) {
    this.myListener = listener;
    this.buy.addActionListener(this);
    this.back.addActionListener(this);
    updatePortfolios();
  }

  // updates the portfolios in the dropdown menu
  private void updatePortfolios() {
    if (myListener != null) {
      portfolios.removeAllItems();
      portfolios.addItem("Select a Portfolio:");
      for (String s : myListener.getPortfolios().split(",")) {
        if (!s.isBlank()) {
          portfolios.addItem(s);
        }
      }
    }
  }


  // gets the ticker symbol from the text field
  private String getTicker() {
    String symbol = tickerField.getText();
    if (symbol.isEmpty()) {
      throw new IllegalArgumentException("Ticker symbol cannot be empty");
    }
    return symbol;
  }

  // gets the share amount from the text field
  private double getShareAmount() {
    if (shareField.getText().isBlank()) {
      throw new IllegalArgumentException("Share amount cannot be empty");
    }
    try {
      return Double.parseDouble(shareField.getText());
    } catch (NumberFormatException e) {
      throw new NumberFormatException("Share Amount must be a number");
    }
  }

  // gets the date from the text field
  private LocalDate getDate() {
    if (dateField.getText().isEmpty()) {
      throw new IllegalArgumentException("Date cannot be empty");
    }
    try {
      return LocalDate.parse(dateField.getText());
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date");
    }
  }

  /**
   * Handles the actions that happen from a users inputs.
   * @param e the event to be processed
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "buy":
        boolean tickE = false;
        boolean shareE = false;
        boolean dateE = false;
        try {
          if (!myListener.verifyStock(getTicker())) {
            resultLabel.setText("The given stock does not exist");
            tickE = true;
          }
          getShareAmount();
          LocalDate date = getDate();
          if (!myListener.verifyDate(getTicker(), date)) {
            resultLabel.setText("Invalid date for the selected stock");
            dateE = true;
          } else {
            myListener.updatePort(Objects.requireNonNull(portfolios.getSelectedItem()).toString());
            myListener.buyStocks(getTicker(), getShareAmount(), date);
            resultLabel.setForeground(Color.BLACK);
            resultLabel.setText(getShareAmount() + " share(s) of " + getTicker() +
                    " successfully bought on " +
                    date);
            tickE = true;
            shareE = true;
            dateE = true;
          }
        } catch (Exception er) {
          resultLabel.setText("Error: " + er.getMessage());
          if (resultLabel.getText().contains("Share")) {
            shareE = true;
          }
        }
        resultLabel.setVisible(true);
        if (time.isRunning()) {
          time.restart();
          if (resultLabel.getText().contains("Error")) {
            resultLabel.setForeground(Color.RED);
          } else {
            resultLabel.setForeground(Color.BLACK);
          }
        } else {
          time.start();
        }
        clearFields(tickE, shareE, dateE);
        break;
      case "back":
        view.setVisible(true);
        this.setVisible(false);
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
  }

  // clear the text fields
  private void clearFields(boolean tickE, boolean shareE, boolean dateE) {
    if (tickE) {
      tickerField.setText(TICKPLACE);
      tickerField.setForeground(Color.GRAY);
    }
    if (shareE) {
      shareField.setText(SHAREPLACE);
      shareField.setForeground(Color.GRAY);
    }
    if (dateE) {
      dateField.setText(PLACEHOLDER);
      dateField.setForeground(Color.GRAY);
    }
  }
}

