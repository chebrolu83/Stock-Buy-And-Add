package view;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.time.LocalDate;
import java.util.Objects;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.Timer;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.Box;


/**
 * Represents the view window that handles the functionality for getting the composition of a
 * portfolio.
 */
public class CompView extends JFrame implements IView, ActionListener {
  private IViewListener myListener;
  private final JTextField dateField;
  private final JButton back;
  private final JButton get;
  private JLabel resultLabel;
  private final IView view;
  private final JComboBox<String> portfolios;
  private final Timer time;

  private static final String PLACEHOLDER = "YYYY-MM-DD";

  /**
   * Constructs the composition view window.
   *
   * @param view the view previously to allow a user to return to it
   */
  public CompView(IView view) {
    super();
    setSize(new Dimension(900, 300));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    setLayout(new BorderLayout());
    JLabel dataLabel = new JLabel("Enter Date:");
    this.dateField = new JTextField(10);
    this.view = view;
    this.portfolios = new JComboBox<>();
    this.back = new JButton("Back To Menu");
    this.get = new JButton("Get Composition");
    this.resultLabel = new JLabel();
    resultLabel.setForeground(Color.RED);

    this.get.setActionCommand("get");
    this.back.setActionCommand("back");

    dateField.setText(PLACEHOLDER);
    dateField.setForeground(Color.GRAY);

    dateField.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(FocusEvent e) {
        if (dateField.getText().equals("YYYY-MM-DD")) {
          dateField.setText("");
          dateField.setForeground(Color.BLACK);
        }
      }

      @Override
      public void focusLost(FocusEvent e) {
        if (dateField.getText().isEmpty()) {
          dateField.setText("YYYY-MM-DD");
          dateField.setForeground(Color.GRAY);
        }
      }
    });

    JPanel combo = new JPanel(new GridLayout(1, 1));
    portfolios.setPreferredSize(new Dimension(dateField.getPreferredSize().width +
            dataLabel.getPreferredSize().width, portfolios.getPreferredSize().height));
    combo.add(portfolios);
    JPanel inputPanel = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.anchor = GridBagConstraints.CENTER;
    c.insets = new Insets(10, 10, 20, 10);

    c.gridx = 0;
    c.gridy = 0;
    inputPanel.add(combo, c);


    c.gridx = 1;
    inputPanel.add(Box.createHorizontalStrut(10), c);


    c.gridx = 2;
    inputPanel.add(dataLabel, c);
    c.gridx = 3;
    inputPanel.add(dateField, c);


    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    buttonPanel.add(get);
    buttonPanel.add(back);


    c.gridy = 1;
    c.gridx = 1;
    inputPanel.add(buttonPanel, c);

    c.gridy = 2;
    c.gridx = 1;
    inputPanel.add(resultLabel, c);

    JPanel dummyPanel = new JPanel();
    dummyPanel.setPreferredSize(new Dimension(0, 0));
    dummyPanel.setFocusable(true);
    inputPanel.add(dummyPanel);

    add(inputPanel, BorderLayout.CENTER);

    time = new Timer(5000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        resultLabel.setVisible(false);
        resultLabel.setForeground(Color.RED);
        revalidate();
        repaint();
      }
    });
    time.setRepeats(false);

  }

  /**
   * Adds the view listener from before to this class to retrieve inputs.
   *
   * @param listener the listener that will retrieve inputs
   */
  @Override
  public void addViewListener(IViewListener listener) {
    this.myListener = listener;
    this.back.addActionListener(this);
    this.get.addActionListener(this);
    updatePortfolios();
  }

  // Updates the portfolio drop down menu
  private void updatePortfolios() {
    if (myListener != null) {
      portfolios.removeAllItems();
      portfolios.addItem("Select a Portfolio:");
      for (String s : myListener.getPortfolios().split(",")) {
        if (!s.isBlank()) {
          portfolios.addItem(s);
        }
      }
    }
  }

  // Gets the date from the text field
  private LocalDate getDate() {
    if (dateField.getText().isEmpty()) {
      throw new IllegalArgumentException("Date cannot be empty");
    }
    try {
      return LocalDate.parse(dateField.getText());
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date");
    }
  }

  // Gets the portfolio name from the dropdown menu
  private String getPortName() {
    if (Objects.requireNonNull(portfolios.getSelectedItem()).toString().contains("Select")) {
      throw new IllegalArgumentException("Select a Valid Portfolio");
    }
    return portfolios.getSelectedItem().toString();
  }

  /**
   * Handles action inputs from the user.
   *
   * @param e the event to be processed
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "get":
        try {
          myListener.updatePort(getPortName());
          String comp = myListener.getComp(getDate());
          resultLabel.setForeground(Color.BLACK);
          if (comp.isBlank()) {
            resultLabel.setText("The " + getPortName() + " portfolio is empty on the given date");
          } else {
            resultLabel.setText(comp);
          }

        } catch (Exception er) {
          resultLabel.setText("Error: " + er.getMessage());

        }
        dateField.setText(PLACEHOLDER);
        dateField.setForeground(Color.GRAY);
        resultLabel.setVisible(true);
        if (time.isRunning()) {
          time.restart();
          if (resultLabel.getText().contains("Error")) {
            resultLabel.setForeground(Color.RED);
          } else {
            resultLabel.setForeground(Color.BLACK);
          }
        } else {
          time.start();
        }
        break;
      case "back":
        view.setVisible(true);
        this.setVisible(false);
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
  }

}



