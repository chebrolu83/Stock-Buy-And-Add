package view;

/**
 * Represents an IView that can add listeners and set certain versions of the view to be visible
 * which then allows a user to interact with them.
 */
public interface IView {

  /**
   * Adds a viewListener to a certain view so it can be interacted with.
   *
   * @param listener the listener that will retrieve inputs
   */
  void addViewListener(IViewListener listener);

  /**
   * Sets a view to be visible or not visible.
   *
   * @param value true if visible false if not visible
   */
  void setVisible(boolean value);

}
