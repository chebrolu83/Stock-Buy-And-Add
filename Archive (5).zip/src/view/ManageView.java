package view;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Font;



/**
 * Represents the manage portfolio window of the view, which allows a user to buy and sell stocks,
 * as well as to get the value and query the composition.
 */
public class ManageView extends JFrame implements IView, ActionListener {
  private final JButton buyStocks;
  private final JButton sellStocks;
  private final JButton getVal;
  private final JButton getComp;
  private final JButton back;
  private IViewListener myListener;
  private IView view;


  /**
   * Constructs the manage portfolio window so the user can interact with it.
   *
   * @param view the previous view to go back to
   */
  public ManageView(IView view) {
    super();
    this.view = view;
    setSize(new Dimension(900, 300));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


    setLayout(new BorderLayout());
    JLabel title = new JLabel("Manage Portfolio", JLabel.CENTER);
    title.setFont(new Font("Arial", Font.BOLD, 20));
    this.buyStocks = new JButton("Buy Stocks");
    this.sellStocks = new JButton("Sell Stocks");
    this.getVal = new JButton("Get Value");
    this.getComp = new JButton("Get Composition");
    this.back = new JButton("Back to Menu");

    this.buyStocks.setActionCommand("buy");
    this.sellStocks.setActionCommand("sell");
    this.getVal.setActionCommand("val");
    this.getComp.setActionCommand("comp");
    this.back.setActionCommand("back");


    JPanel buttonPanel = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    buyStocks.setPreferredSize(new Dimension(150, 50));
    c.gridx = 1;
    c.gridy = 0;
    c.fill = GridBagConstraints.BOTH;
    buttonPanel.add(buyStocks, c);

    // Sell Stocks button
    sellStocks.setPreferredSize(new Dimension(150, 50));
    c.gridx = 2;
    buttonPanel.add(sellStocks, c);

    // Get Value button
    getVal.setPreferredSize(new Dimension(150, 50));
    c.gridx = 3;
    buttonPanel.add(getVal, c);

    // Get Composition button
    getComp.setPreferredSize(new Dimension(150, 50));
    c.gridx = 4;
    buttonPanel.add(getComp, c);

    // Back to Menu button
    back.setPreferredSize(new Dimension(150, 50));
    c.gridx = 2;
    c.gridy = 1;
    c.gridwidth = 2;
    buttonPanel.add(back, c);


    add(title, BorderLayout.NORTH);

    JPanel dummyPanel = new JPanel();
    dummyPanel.setPreferredSize(new Dimension(0, 0));
    dummyPanel.setFocusable(true);
    buttonPanel.add(dummyPanel);

    add(buttonPanel, BorderLayout.CENTER);

  }

  /**
   * Handles inputs from the user and outputs actions.
   *
   * @param e the event to be processed
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "buy":
        IView b = new BuyView(this);
        b.addViewListener(myListener);
        b.setVisible(true);
        this.setVisible(false);
        break;
      case "sell":
        IView s = new SellView(this);
        s.addViewListener(myListener);
        s.setVisible(true);
        this.setVisible(false);
        break;
      case "val":
        IView v = new ValueView(this);
        v.addViewListener(myListener);
        v.setVisible(true);
        this.setVisible(false);
        break;
      case "comp":
        IView c = new CompView(this);
        c.addViewListener(myListener);
        c.setVisible(true);
        this.setVisible(false);
        break;
      case "back":
        view.setVisible(true);
        this.setVisible(false);
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
  }

  /**
   * Adds the view listener from before to this class to retrieve inputs.
   *
   * @param listener the listener that will retrieve inputs
   */
  @Override
  public void addViewListener(IViewListener listener) {
    this.myListener = listener;
    this.buyStocks.addActionListener(this);
    this.sellStocks.addActionListener(this);
    this.getVal.addActionListener(this);
    this.getComp.addActionListener(this);
    this.back.addActionListener(this);
  }
}
