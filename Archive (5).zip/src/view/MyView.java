package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.util.Objects;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.Timer;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.SwingConstants;


/**
 * Represents the main menu for the view windows, allows a user to create, upload, and save
 * portfolios, as well as to manage them.
 */
public class MyView extends JFrame implements IView, ActionListener {
  private final JButton createPort;
  private final JTextField createName;
  private final JButton managePort;
  private final JComboBox<String> saveOptions;
  private final JButton save;
  private final JComboBox<String> uploadOptions;
  private final JLabel result;
  private final JButton upload;
  private IViewListener myListener;
  private final Timer time;


  private static final String CREATEPLACE = "Enter Name Here:";


  /**
   * Constructs the main menu of the GUI to be interacted with by the user.
   */
  public MyView() {
    super();
    setSize(new Dimension(900, 300));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


    JPanel frame = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(10, 10, 10, 10);
    JLabel title = new JLabel("Stock Program", JLabel.CENTER);
    title.setFont(new Font("Arial", Font.BOLD, 20));
    c.gridx = 2;
    c.gridy = 0;
    frame.add(title, c);
    this.createPort = new JButton("Create");
    this.createName = new JTextField(10);
    this.managePort = new JButton("Manage Portfolio");
    this.saveOptions = new JComboBox<>();
    this.save = new JButton("Save");
    this.uploadOptions = new JComboBox<>();
    this.upload = new JButton("Upload");
    this.result = new JLabel();
    result.setForeground(Color.RED);

    this.createPort.setActionCommand("create");
    this.managePort.setActionCommand("manage");
    this.save.setActionCommand("save");
    this.upload.setActionCommand("upload");

    createName.setText(CREATEPLACE);
    createName.setForeground(Color.GRAY);

    createName.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(FocusEvent e) {
        if (createName.getText().equals("Enter Name Here:")) {
          createName.setText("");
          createName.setForeground(Color.BLACK);
        }
      }

      @Override
      public void focusLost(FocusEvent e) {
        if (createName.getText().isEmpty()) {
          createName.setText("Enter Name Here:");
          createName.setForeground(Color.GRAY);
        }
      }
    });


    c.gridx = 2;
    c.gridy = 1;
    c.gridwidth = 1;
    c.fill = GridBagConstraints.HORIZONTAL;

    frame.add(managePort, c);

    c.gridy = 3;
    c.gridx = 0;
    frame.add(saveOptions, c);

    c.gridx = 1;
    frame.add(save, c);

    c.gridx = 3;
    frame.add(uploadOptions, c);


    c.gridx = 4;
    frame.add(upload, c);


    JPanel create = new JPanel(new FlowLayout(FlowLayout.LEFT));
    create.add(createPort);
    create.add(createName);

    c.gridy = 4;
    c.gridx = 2;
    frame.add(create, c);


    JPanel dummyPanel = new JPanel();
    dummyPanel.setPreferredSize(new Dimension(0, 0));
    dummyPanel.setFocusable(true);
    frame.add(dummyPanel);



    this.getContentPane().add(frame, BorderLayout.NORTH);


    time = new Timer(3500, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        remove(result);
        result.setForeground(Color.RED);
        revalidate();
        repaint();
      }
    });
    time.setRepeats(false);

  }


  /**
   * Handles inputs from the user to output actions.
   *
   * @param e the event to be processed
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "create":
        String name = createName.getText();
        try {
          myListener.createPort(name);
          result.setForeground(Color.BLACK);
          showResult(name + " has successfully been created and can now be managed");
        } catch (Exception e1) {
          showResult("Error: " + e1.getMessage());
        }
        initializeComboBoxes();
        createName.setText(CREATEPLACE);
        createName.setForeground(Color.GRAY);
        break;
      case "manage":
        IView v = new ManageView(this);
        v.addViewListener(myListener);
        v.setVisible(true);
        this.setVisible(false);
        break;
      case "save":
        try {
          String port = Objects.requireNonNull(saveOptions.getSelectedItem()).toString();
          myListener.updatePort(port);
          myListener.savePort();
          result.setForeground(Color.BLACK);
          showResult("The " + port + " portfolio has been saved");
        } catch (Exception er) {
          showResult("Error: " + er.getMessage());
        }
        initializeComboBoxes();
        break;
      case "upload":
        try {
          String port = Objects.requireNonNull(uploadOptions.getSelectedItem())
                  .toString().split("\\.")[0];
          myListener.uploadPort(port);
          result.setForeground(Color.BLACK);
          showResult("The " + port + " portfolio has been uploaded");
        } catch (Exception er) {
          showResult("Error: " + er.getMessage());
        }
        initializeComboBoxes();
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
  }

  /**
   * Adds the view listener from before to this class to retrieve inputs.
   *
   * @param listener the listener that will retrieve inputs
   */
  public void addViewListener(IViewListener listener) {
    this.myListener = listener;
    this.createPort.addActionListener(this);
    this.managePort.addActionListener(this);
    this.save.addActionListener(this);
    this.upload.addActionListener(this);

    initializeComboBoxes();
  }

  // Initialize the dropdown boxes
  private void initializeComboBoxes() {
    if (myListener != null) {
      saveOptions.removeAllItems();
      saveOptions.addItem("Select Portfolio:");
      for (String s : myListener.getPortfolios().split(",")) {
        if (!s.isBlank()) {
          saveOptions.addItem(s);
        }
      }

      File f = new File("res/portfolios");
      File[] files = f.listFiles();

      uploadOptions.removeAllItems();
      uploadOptions.addItem("Select Portfolio:");
      if (files != null) {
        for (File x : files) {
          uploadOptions.addItem(x.getName());
        }
      }
    }
  }

  // Shows the result of main menu queries
  private void showResult(String s) {
    result.setText(s);
    result.setHorizontalAlignment(SwingConstants.CENTER);
    add(result);
    revalidate();
    repaint();

    if (time.isRunning()) {
      time.restart();
      if (result.getText().contains("Error")) {
        result.setForeground(Color.RED);
      } else {
        result.setForeground(Color.BLACK);
      }
    } else {
      time.start();
    }
  }
}
