import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;

import model.Data;
import model.Model;
import model.StockModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


/**
 * The class holding model tests.
 */
public class ModelTest {
  StockModel m;
  private Map<LocalDate, Data> output;
  private Map<LocalDate, Data> output2;

  @Before
  public void setUp() throws Exception {
    m = new Model();
    m.updateCurrentStock("GOOG");
    m.addStockData();

    output = new TreeMap<>();
    Data stockData1 = new Data(178.4, 178.852, 176.7801, 178,
            16189404);
    Data stockData2 = new Data(178.78, 179.91, 174.54, 175.06,
            14928363);
    Data stockData3 = new Data(176.52, 177.3044, 175.2, 176.33,
            11403560);
    output.put(LocalDate.of(2024, 5, 22), stockData1);
    output.put(LocalDate.of(2024, 5, 23), stockData2);
    output.put(LocalDate.of(2024, 5, 24), stockData3);
  }


  // Test that the model determines correctly that a stock gained or lost during a
  // specified period of time
  @Test
  public void testStockPerformance() {
    double performance = m.performance(LocalDate.of(2024, 5, 22),
            LocalDate.of(2024, 5, 24));
    assertEquals(-1.67, performance, .001); // Tag
  }

  // Test that the model returns the correct x-day moving average for a given stock on a given date
  @Test
  public void testThreeDayMovingAverage() {
    output.put(LocalDate.of(2024, 5, 28), new Data(175.74,
            178.51, 175.68, 178.02, 15655340));
    output.put(LocalDate.of(2024, 5, 29), new Data(176.81,
            178.23, 176.26, 177.4, 15023847));
    double movingAverage = m.movingAvg(5, LocalDate.of(2024, 5, 29));
    assertEquals(176.962, movingAverage, 0.001); // Tag
  }

  // Test the download stock functionality
  @Test
  public void testDownloadStock() throws Exception {
    m.updateCurrentStock("BRK.A");
    m.download();
    File file = new File("res/stockData/BRK.A.csv");
    assertTrue(file.exists());
    file.delete(); // Clean up the test file
  }

  // Test the creation stock functionality
  @Test(expected = IllegalArgumentException.class)
  public void testCreateStockInvalidData() throws Exception {
    m.updateCurrentStock("INVALID");
    m.addStockData();
  }

  // test create portfolio
  @Test
  public void testCreatePort() {
    m.createPortfolio("test");
    StringJoiner o = new StringJoiner(",");
    o.add("test");

    assertEquals(m.getPortfolios().toString(), o.toString());
    m.updateCurrentPort("test");
    assertEquals(m.getCurrentPortfolioName(), "test");
  }

  // testing getting portfolio value
  @Test
  public void testPortVal() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5, LocalDate.of(2024, 6, 5));
    m.portAddStocks("AMZN", 5, LocalDate.of(2024, 6, 5));

    LocalDate date = LocalDate.of(2024, 6, 5);
    assertEquals(m.portValue(date), 1791.75, 0.001);
  }

  // testing getting portfolio value on invalidDate
  @Test(expected = IllegalArgumentException.class)
  public void testPortValInvalid() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5, LocalDate.of(2024, 6, 5));
    m.portAddStocks("AMZN", 5, LocalDate.of(2024, 6, 5));

    LocalDate date = LocalDate.of(2024, 6, 10);
    assertEquals(m.portValue(date), 1797.1, 0.001);
  }

  @Test
  public void testUpdateStock() {
    m.updateCurrentStock("NEW");

    assertEquals(m.currentStockName(), "NEW");
  }


  @Test
  public void testUpdatePort() {
    m.createPortfolio("NEW");
    m.updateCurrentPort("NEW");

    assertEquals(m.getCurrentPortfolioName(), "NEW");
  }

  @Test
  public void testRemove() {
    m.createPortfolio("NEW");

    m.removePortfolio("NEW");
    assertEquals(m.getPortfolios().toString(), new StringJoiner(",").toString());
  }

  @Test
  public void testAddStocks() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5, LocalDate.of(2024, 6, 5));

    String output = m.findPortStocksWithShares(LocalDate.of(2024, 6, 5));
    assertEquals(output, "GOOG: 5.0");
  }

  @Test
  public void testRemoveStock() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5, LocalDate.of(2024, 6, 5));

    String output = m.findPortStocksWithShares(LocalDate.of(2024, 6, 5));
    assertEquals(output, "GOOG: 5.0");

    m.portRemoveStocks("GOOG", 3,
            LocalDate.of(2024, 6, 5));
    String output2 = m.findPortStocksWithShares(LocalDate.of(2024, 6, 5));
    assertEquals(output2, "GOOG: 2.0");
  }

  @Test
  public void testPortfolioValue() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("AAPL", 10, LocalDate.of(2022, 1, 5));
    double value1 = m.portValue(LocalDate.of(2022, 1, 3));
    double value2 = m.portValue(LocalDate.of(2022, 1, 5));
    assertEquals(0, value1, 0.01); // getting val before stock is bought should be 0
    assertEquals(1749.19999, value2, 0.01); // each share is 174.919
  }

  @Test
  public void testRebalance() throws Exception {
    LocalDate date1 = LocalDate.of(2024, 6, 5);
    LocalDate date2 = LocalDate.of(2024, 6, 7);
    List<Double> weights = new ArrayList<>();
    weights.add(25.0);
    weights.add(75.0);
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5.0, date1);
    m.portAddStocks("AMZN", 5.0, date1);

    String comp = m.findPortStocksWithShares(date1);
    String dist = m.findPortStocksWithVals(date1);

    assertEquals(comp, "AMZN: 5.0, GOOG: 5.0");
    assertEquals("AMZN: 906.4, GOOG: 885.3499999999999", dist);

    m.rebalance(date2, weights);
    String comp2 = m.findPortStocksWithShares(date2);
    String dist2 = m.findPortStocksWithVals(date2);

    assertEquals(comp2, "AMZN: 2.443366793271839, GOOG: 7.677962489343564");
    assertEquals("AMZN: 450.31249999999994, GOOG: 1350.9375", dist2);


  }

  @Test
  public void getComp() throws Exception {
    LocalDate date1 = LocalDate.of(2024, 6, 5);
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5.0, date1);
    m.portAddStocks("AMZN", 5.0, date1);

    String comp = m.findPortStocksWithShares(date1);

    assertEquals(comp, "AMZN: 5.0, GOOG: 5.0");
  }

  @Test
  public void getDist() throws Exception {
    LocalDate date1 = LocalDate.of(2024, 6, 5);
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5.0, date1);
    m.portAddStocks("AMZN", 5.0, date1);
    String dist = m.findPortStocksWithVals(date1);

    assertEquals("AMZN: 906.4, GOOG: 885.3499999999999", dist);
  }

  @Test
  public void testGraph() throws Exception {
    m.updateCurrentStock("GOOG");
    m.addStockData();
    LocalDate date1 = LocalDate.of(2024, 6, 3);
    LocalDate date2 = LocalDate.of(2024, 6, 7);
    String result = m.graphStock(date1, date2);

    String output = System.lineSeparator() + "Performance of Stock " +
            "GOOG" + " from " + date1 + " to " +
            date2 + ":" + System.lineSeparator() +
            "2024 " + "Jun 3: " + "*".repeat(44) +
            System.lineSeparator() +
            "2024 " + "Jun 4: " + "*".repeat(44) + System.lineSeparator() +
            "2024 " + "Jun 5: " + "*".repeat(44) + System.lineSeparator() +
            "2024 " + "Jun 6: " + "*".repeat(45) + System.lineSeparator() +
            "2024 " + "Jun 7: " + "*".repeat(44) + System.lineSeparator()
            + System.lineSeparator() +
            "Scale: * = 4.0 Dollars" + System.lineSeparator();


    assertEquals(result, output);
  }

  @Test(expected = IllegalArgumentException.class)
  public void sellTooMuch() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 5, LocalDate.of(2024, 6, 3));
    m.portRemoveStocks("GOOG", 6,
            LocalDate.of(2024, 6, 5));
  }

  @Test(expected = IllegalArgumentException.class)
  public void sellWrongDate() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portRemoveStocks("GOOG", 6,
            LocalDate.of(2024, 8, 5));
  }

  @Test(expected = IllegalArgumentException.class)
  public void buyWrongDate() throws Exception {
    m.createPortfolio("test");
    m.updateCurrentPort("test");
    m.portAddStocks("GOOG", 6,
            LocalDate.of(2024, 8, 5));
  }

  @Test
  public void testParse() throws Exception {
    m.portUpload("test");
    m.updateCurrentPort("test");
    String r = "GOOG: 5.0, AAPL: 10.0, AMZN: 10.0";
    assertEquals(r, m.findPortStocksWithShares(LocalDate.of(2024, 6, 5)));
  }


}



