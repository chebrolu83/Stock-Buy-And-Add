import org.junit.Before;
import org.junit.Test;


import java.io.StringReader;
import java.io.StringWriter;

import controller.StockController;

import static org.junit.Assert.assertTrue;

/**
 * Testing controller.
 */
public class TestStockController {
  private StockController controller;
  private StringWriter writer;

  @Before
  public void setUp() {
    writer = new StringWriter();
    controller = new StockController(new StringReader(""), writer);
  }

  @Test
  public void testDownloadStock() throws Exception {
    String input = "4\nAAPL\nb\nquit\n";
    controller = new StockController(new StringReader(input), writer);
    controller.start();
    String output = writer.toString();
    assertTrue("Download stock message missing",
            output.contains("AAPL has been downloaded and can be accessed next time the program " +
                    "is run"));
  }


  @Test
  public void testStartMethod() throws Exception {
    String input = "menu\nquit\n";
    controller = new StockController(new StringReader(input), writer);
    controller.start();
    String output = writer.toString();

    // Check for the welcome message
    assertTrue("Welcome message missing",
            output.contains("Welcome to the stock program!"));

    // Check for the menu display
    assertTrue("Menu not displayed",
            output.contains("Supported user instructions are:"));

    // Check for the quit message
    assertTrue("Farewell message missing",
            output.contains("Thank you for using this program!"));
  }
}
